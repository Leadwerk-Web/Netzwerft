<?php
/**
 * Standalone smoke test for strict WordPress version import compatibility.
 * Run with: php tests/wordpress-version-compatibility-smoke.php
 */

define( 'ABSPATH', __DIR__ . '/' );

class Leadwerk_Migration_Compatibility_Exception extends Exception {}

class Leadwerk_Migration_Status {
	public static $messages = array();

	public static function info( $message ) {
		self::$messages[] = $message;
	}
}

function __( $message ) {
	return $message;
}

function esc_html( $value ) {
	return htmlspecialchars( $value, ENT_QUOTES, 'UTF-8' );
}

function wp_kses( $value ) {
	return $value;
}

function leadwerk_migration_allowed_html_tags() {
	return array( 'strong' => array() );
}

function leadwerk_migration_package_path( $params ) {
	return $params['package_path'];
}

function leadwerk_migration_open( $path, $mode ) {
	return fopen( $path, $mode );
}

function leadwerk_migration_read( $handle, $length ) {
	return fread( $handle, $length );
}

function leadwerk_migration_close( $handle ) {
	return fclose( $handle );
}

function leadwerk_version_assert( $condition, $message ) {
	if ( ! $condition ) {
		fwrite( STDERR, "FAIL: {$message}\n" );
		exit( 1 );
	}
}

function leadwerk_version_package( $version = null ) {
	$package = array();
	if ( $version !== null ) {
		$package['WordPress'] = array( 'Version' => $version );
	}

	$path = tempnam( sys_get_temp_dir(), 'lwm-wp-version-' );
	file_put_contents( $path, json_encode( $package ) );

	return $path;
}

require_once dirname( __DIR__ ) . '/lib/model/import/class-leadwerk_migration-import-wordpress-version.php';

$wp_version = '7.0.4';
$matching   = leadwerk_version_package( '7.0.4' );
$params     = array( 'package_path' => $matching, 'sentinel' => true );
$result     = Leadwerk_Migration_Import_WordPress_Version::execute( $params );
leadwerk_version_assert( $result === $params, 'matching versions should continue the import' );
unlink( $matching );

$mismatch_blocked = false;
$mismatching      = leadwerk_version_package( '7.0.2' );
try {
	Leadwerk_Migration_Import_WordPress_Version::execute( array( 'package_path' => $mismatching ) );
} catch ( Leadwerk_Migration_Compatibility_Exception $error ) {
	$mismatch_blocked = strpos( $error->getMessage(), '7.0.2' ) !== false && strpos( $error->getMessage(), '7.0.4' ) !== false;
}
leadwerk_version_assert( $mismatch_blocked, 'different source and destination versions must be blocked with both versions in the error' );
unlink( $mismatching );

$missing_blocked = false;
$missing         = leadwerk_version_package();
try {
	Leadwerk_Migration_Import_WordPress_Version::execute( array( 'package_path' => $missing ) );
} catch ( Leadwerk_Migration_Compatibility_Exception $error ) {
	$missing_blocked = strpos( $error->getMessage(), 'does not contain a valid source WordPress version' ) !== false;
}
leadwerk_version_assert( $missing_blocked, 'missing source version metadata must be blocked' );
unlink( $missing );

$wp_version          = '';
$unknown_destination = false;
$source_known        = leadwerk_version_package( '7.0.4' );
try {
	Leadwerk_Migration_Import_WordPress_Version::execute( array( 'package_path' => $source_known ) );
} catch ( Leadwerk_Migration_Compatibility_Exception $error ) {
	$unknown_destination = strpos( $error->getMessage(), 'destination WordPress version could not be determined' ) !== false;
}
leadwerk_version_assert( $unknown_destination, 'an unknown destination version must be blocked' );
unlink( $source_known );

fwrite( STDOUT, "WordPress version compatibility smoke tests passed.\n" );
