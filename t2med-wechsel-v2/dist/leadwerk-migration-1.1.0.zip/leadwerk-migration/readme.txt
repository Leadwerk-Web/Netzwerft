=== Leadwerk Migration & Backup ===
Contributors: leadwerk
Tags: migration, backup, restore, automation, wp-cli
Requires at least: 6.2
Requires PHP: 7.4
Stable tag: 1.1.0
License: GPLv3 or later
License URI: https://www.gnu.org/licenses/gpl-3.0.html

Secure WordPress migrations with verified private backups, automation, retention, environment health checks, REST, and WP-CLI.

== Description ==

Leadwerk Migration & Backup packages a WordPress site into a portable `.wpress` archive and imports compatible archives through a guided workflow.

Leadwerk adds an operations layer around the proven migration pipeline:

* Migration health dashboard with PHP, WordPress, filesystem privacy/writability, disk, memory, upload, HTTPS, OpenSSL, cron, and database checks.
* Randomized backup and runtime working directories outside detected web roots, with authenticated download streaming and defense-in-depth deny rules.
* SHA-256 integrity manifests and on-demand verification.
* Optional AES-256-GCM v3 archive encryption with PBKDF2-SHA256 key derivation, path- and position-bound chunk authentication, and a final keyed whole-archive manifest.
* Hourly, daily, weekly, or monthly local automation.
* Count-based retention limited to backups created by the scheduler.
* Optional success and failure email notifications.
* Atomic backup locking with a progress heartbeat and a bounded activity history.
* Capability, exact-scope and action-nonce checks for administrative actions, plus job-bound signed continuation tickets.
* Job-scoped, expiring tokens for REST import polling; the server secret is never returned by REST.
* Real WP-CLI backup, list, verify, health, and schedule commands.
* Fail-closed import guard requiring the backup and destination to use the exact same WordPress core version.
* Hub-coordinated Site Sync between local, staging and live WordPress environments using outbound-only signed HTTPS requests.
* Zone Zero Site Family identity, unique per-environment credentials, five-minute heartbeats and visible online/offline state.
* Fail-closed sync preflight requiring exact WordPress, PHP and plugin versions before a backup or destructive action begins.
* Automatic destination safety backup, resumable SHA-256-verified relay transfer and no per-job dual-environment approval.

Leadwerk Migration is an independent GPLv3 fork. It is not affiliated with or endorsed by ServMask. See `NOTICE.md` for upstream and third-party attribution.

== Installation ==

1. Copy the `leadwerk-migration` directory into `/wp-content/plugins/` or upload the release ZIP from Plugins → Add New.
2. Activate **Leadwerk Migration & Backup**.
3. Open Leadwerk Migration → Overview and run the health checks.
4. Create a backup before importing into a production site.

For Site Sync, open Leadwerk Migration → Site Sync. Create the Zone Zero backup on the original installation, install that backup on sibling environments, and register each environment with the Leadwerk Hub. A Hub administrator approves the Site Family and each environment once. Later sync jobs do not require approval on both sites. If the target is live, the initiating administrator must explicitly enter `SYNC LIVE`.

Every environment sends a heartbeat to the Hub through WP-Cron every five minutes and is shown as offline after fifteen minutes. WordPress cron requires site traffic; configure a real server cron to call `wp-cron.php` every five minutes for reliable presence monitoring. Hostnames ending in `.local` are detected as local, and any hostname containing `myrdbx.io` is detected as staging.

By default, Leadwerk prefers a writable directory beside the WordPress root only when it is outside the detected document root. If that location is unavailable or web-served, it falls back to the operating-system temporary directory. It does not publish a runtime URL, administrative downloads pass through protected PHP endpoints, and migrations fail closed for paths detected below a web root. The Overview screen reports privacy, writability, and the temporary-backup fallback. For durable backups, define `LEADWERK_MIGRATION_PRIVATE_ROOT` in `wp-config.php` as a writable persistent path outside every document root.

== Frequently Asked Questions ==

= Where are backups stored? =

Backups and temporary migration files use separate randomized directories. Leadwerk prefers a writable parent outside the detected document root and otherwise uses the operating-system temporary directory. The health report warns when durable backups need a persistent custom `LEADWERK_MIGRATION_PRIVATE_ROOT`. The plugin installs defense-in-depth deny rules, publishes no runtime-storage URL, and sends downloads through capability-checked, nonce-protected PHP streams. Administrators must still verify that custom aliases, CDNs, and web-server configuration do not expose either directory.

= Can I automate backups without a cloud account? =

Yes. Leadwerk uses WP-Cron for local backup schedules. Low-traffic sites should configure a system cron to call `wp-cron.php` regularly.

= How does integrity verification work? =

Every Leadwerk-created backup receives a SHA-256 manifest and sidecar. Verification hashes the current file and uses a timing-safe comparison against the stored baseline.

= How are password-protected exports encrypted? =

New encrypted exports use the Leadwerk AES-256-GCM v3 format. Each chunk is authenticated with additional data that binds the archive identifier, normalized path, file size, byte offset, and chunk length. A final password-authenticated manifest covers every preceding archive header and payload byte, including the ordered file set, and is verified before destructive extraction. Keys are derived with PBKDF2-SHA256 and a random salt. Use a unique password of at least 12 characters and store it outside WordPress.

Legacy archives, including older AES-CBC archives, do not contain the v3 keyed whole-archive manifest. They remain importable for compatibility, but Leadwerk displays a distinct unauthenticated-archive warning and requires explicit confirmation before the destructive import stage. Continue only when the source is trusted and an independent checksum has been verified.

= Does the plugin support one-click restore from the backup list? =

Restore is intentionally routed through the Import screen so the destructive confirmation and compatibility checks remain visible. Download the backup, open Import, and select the `.wpress` file.

= Which WP-CLI commands are available? =

Run `wp help leadwerk-migration`. Commands include `backup`, `export`, `list`, `verify`, `health`, and `schedule`.

== Security ==

Imports overwrite site data. Use HTTPS, restrict administrator access, verify archive provenance, and maintain an independent recovery copy. Report suspected vulnerabilities privately to the site owner or package maintainer; do not include secrets or archive contents in public reports.

== Changelog ==

= 1.1.0 =

* Added Zone Zero identity, central Hub enrollment and full local/staging/live Site Sync.
* Added five-minute outbound heartbeat monitoring with a fifteen-minute offline threshold.
* Require exact WordPress, PHP and plugin versions before synchronization and again before import.
* Removed per-job approval from both environments; retained explicit confirmation for a live target.
* Added resumable private relay transfer, SHA-256 verification and destination safety backups.

= 1.0.2 =

* Block imports before any destructive stage when the backup and destination WordPress versions differ.
* Block imports when the backup does not contain valid WordPress version metadata.
* Keep the pipeline completion state bound to signed continuation tickets.

= 1.0.1 =

* Preserve WP Mail SMTP option names and encryption keys when source and destination database table prefixes differ.

= 1.0.0 =

* Independent Leadwerk namespace and plugin identity.
* Added health dashboard, verified backups, scheduler, retention, activity log, and notifications.
* Added authenticated streaming downloads plus separate randomized backup and runtime working directories outside detected web roots, with a safe temporary fallback.
* Added AES-256-GCM v3 archive encryption with chunk AAD, a final keyed whole-archive manifest, and explicitly confirmed legacy archive read compatibility.
* Added scoped REST polling tokens, signed job-bound pipeline continuation tickets, and complete WP-CLI operational commands.
* Removed upstream advertising, updater wiring, and placeholder premium screens from the active interface.
* Preserved the GPL migration/import pipeline and upstream notices.
