<?php
/** Widget, shortcode and template helper for published language pairs. */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class Leadwerk_Language_Switcher extends WP_Widget {
	public function __construct() {
		parent::__construct( 'leadwerk_language_switcher', 'Leadwerk Language Switcher', array( 'description' => 'Zeigt nur veröffentlichte Sprachgegenstücke.' ) );
	}

	public static function init() {
		add_action( 'widgets_init', array( __CLASS__, 'register_widget' ) );
		add_shortcode( 'leadwerk_language_switcher', array( __CLASS__, 'shortcode' ) );
		add_action( 'wp_footer', array( __CLASS__, 'automatic' ), 90 );
	}

	public static function automatic() {
		if ( ! get_option( 'leadwerk_translation_auto_switcher', false ) ) {
			return;
		}
		$html = self::render( array( 'style' => get_option( 'leadwerk_translation_switcher_style', 'compact' ) ) );
		if ( '' === $html ) {
			return;
		}
		echo '<div class="leadwerk-language-switcher-floating"><span class="leadwerk-language-switcher-floating__icon" aria-hidden="true"><svg viewBox="0 0 24 24" focusable="false"><circle cx="12" cy="12" r="9"></circle><path d="M3 12h18M12 3c2.4 2.5 3.6 5.5 3.6 9S14.4 18.5 12 21M12 3C9.6 5.5 8.4 8.5 8.4 12s1.2 6.5 3.6 9"></path></svg></span>' . $html . '</div>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Static SVG and escaped render output.
		echo '<style>
		.leadwerk-language-switcher-floating{position:fixed;right:max(16px,env(safe-area-inset-right));bottom:max(104px,calc(env(safe-area-inset-bottom) + 88px));z-index:9997;display:flex;align-items:center;gap:7px;padding:6px;border:1px solid rgba(255,255,255,.3);border-radius:999px;background:rgba(0,39,60,.94);box-shadow:0 14px 38px rgba(0,39,60,.3);backdrop-filter:blur(12px);-webkit-backdrop-filter:blur(12px)}
		.leadwerk-language-switcher-floating__icon{display:grid;place-items:center;width:30px;height:30px;color:#fff}.leadwerk-language-switcher-floating__icon svg{width:20px;height:20px;fill:none;stroke:currentColor;stroke-width:1.7;stroke-linecap:round;stroke-linejoin:round}
		.leadwerk-language-switcher{display:flex;align-items:center;gap:3px;margin:0}.leadwerk-language-switcher__link{display:grid;place-items:center;min-width:38px;min-height:34px;padding:5px 10px;border-radius:999px;color:#fff!important;font:700 12px/1 Montserrat,Arial,sans-serif;letter-spacing:.05em;text-decoration:none!important;transition:background-color .2s ease,color .2s ease,transform .2s ease}.leadwerk-language-switcher__link:hover{background:rgba(255,255,255,.14);transform:translateY(-1px)}.leadwerk-language-switcher__link.is-active{background:#1e88e5;color:#fff!important;box-shadow:0 4px 12px rgba(30,136,229,.32)}.leadwerk-language-switcher__link:focus-visible{outline:3px solid #64b5f6;outline-offset:2px}
		@media(max-width:600px){.leadwerk-language-switcher-floating{right:max(10px,env(safe-area-inset-right));bottom:max(82px,calc(env(safe-area-inset-bottom) + 72px));gap:3px;padding:4px}.leadwerk-language-switcher-floating__icon{width:26px;height:30px}.leadwerk-language-switcher__link{min-width:34px;min-height:32px;padding:5px 8px}}
		@media(prefers-reduced-motion:reduce){.leadwerk-language-switcher__link{transition:none}}
		</style>';
	}

	public static function register_widget() { register_widget( __CLASS__ ); }

	public function widget( $args, $instance ) {
		echo wp_kses_post( $args['before_widget'] ?? '' );
		echo self::render( $instance ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Escaped by render().
		echo wp_kses_post( $args['after_widget'] ?? '' );
	}

	public function form( $instance ) {
		$style = sanitize_key( (string) ( $instance['style'] ?? 'compact' ) );
		?>
		<p><label for="<?php echo esc_attr( $this->get_field_id( 'style' ) ); ?>">Darstellung</label>
		<select id="<?php echo esc_attr( $this->get_field_id( 'style' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'style' ) ); ?>">
			<option value="compact" <?php selected( $style, 'compact' ); ?>>DE / EN</option>
			<option value="names" <?php selected( $style, 'names' ); ?>>Sprachnamen</option>
		</select></p>
		<?php
	}

	public function update( $new_instance, $old_instance ) {
		$style = sanitize_key( (string) ( $new_instance['style'] ?? 'compact' ) );
		return array( 'style' => in_array( $style, array( 'compact', 'names' ), true ) ? $style : 'compact' );
	}

	public static function shortcode( $atts ) {
		$atts = shortcode_atts( array( 'style' => 'compact' ), $atts, 'leadwerk_language_switcher' );
		return self::render( $atts );
	}

	public static function render( $options = array() ) {
		$urls = class_exists( 'Leadwerk_Translation_Router' ) ? Leadwerk_Translation_Router::get_current_page_alternate_urls() : array();
		if ( count( $urls ) < 2 ) {
			return '';
		}
		$style   = 'names' === sanitize_key( (string) ( $options['style'] ?? 'compact' ) ) ? 'names' : 'compact';
		$current = Leadwerk_Translation_API::current_language();
		$nav_label = 'en' === $current ? 'Change language' : 'Sprache wechseln';
		$html      = '<nav class="leadwerk-language-switcher leadwerk-language-switcher--' . esc_attr( $style ) . '" aria-label="' . esc_attr( $nav_label ) . '">';
		foreach ( array( 'de' => 'Deutsch', 'en' => 'English' ) as $code => $name ) {
			$label = 'names' === $style ? $name : strtoupper( $code );
			$html .= '<a class="leadwerk-language-switcher__link' . ( $current === $code ? ' is-active' : '' ) . '" href="' . esc_url( $urls[ $code ] ) . '" hreflang="' . esc_attr( $code ) . '" lang="' . esc_attr( $code ) . '"' . ( $current === $code ? ' aria-current="page"' : '' ) . '>' . esc_html( $label ) . '</a>';
		}
		return $html . '</nav>';
	}
}

if ( ! function_exists( 'leadwerk_language_switcher' ) ) {
	function leadwerk_language_switcher( $options = array() ) {
		echo Leadwerk_Language_Switcher::render( $options ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
	}
}
