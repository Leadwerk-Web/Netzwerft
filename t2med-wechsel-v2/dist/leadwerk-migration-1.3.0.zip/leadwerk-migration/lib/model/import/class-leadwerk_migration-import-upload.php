<?php
/**
 * Copyright (C) 2014-2025 ServMask Inc.
 * Modifications Copyright (C) 2026 Leadwerk.
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 *
 * Upstream attribution: This file derives from the All-in-One WP Migration plugin, developed by
 *
 * ███████╗███████╗██████╗ ██╗   ██╗███╗   ███╗ █████╗ ███████╗██╗  ██╗
 * ██╔════╝██╔════╝██╔══██╗██║   ██║████╗ ████║██╔══██╗██╔════╝██║ ██╔╝
 * ███████╗█████╗  ██████╔╝██║   ██║██╔████╔██║███████║███████╗█████╔╝
 * ╚════██║██╔══╝  ██╔══██╗╚██╗ ██╔╝██║╚██╔╝██║██╔══██║╚════██║██╔═██╗
 * ███████║███████╗██║  ██║ ╚████╔╝ ██║ ╚═╝ ██║██║  ██║███████║██║  ██╗
 * ╚══════╝╚══════╝╚═╝  ╚═╝  ╚═══╝  ╚═╝     ╚═╝╚═╝  ╚═╝╚══════╝╚═╝  ╚═╝
 */

if ( ! defined( 'ABSPATH' ) ) {
	die( 'Kangaroos cannot jump here' );
}

class Leadwerk_Migration_Import_Upload {

	public static function execute( $params ) {

		// #region agent log
		$__lw_dbg = static function ( $hypothesis_id, $message, $data = array() ) use ( $params ) {
			$payload = array(
				'sessionId'    => 'e5acb9',
				'runId'        => 'post-fix',
				'hypothesisId' => $hypothesis_id,
				'location'     => 'class-leadwerk_migration-import-upload.php:execute',
				'message'      => $message,
				'data'         => $data,
				'timestamp'    => (int) round( microtime( true ) * 1000 ),
			);
			$line = wp_json_encode( $payload ) . "\n";
			@file_put_contents( '/Users/atlas/Documents/New project 2/leadwerk-migration/.cursor/debug-e5acb9.log', $line, FILE_APPEND );
			if ( defined( 'LEADWERK_MIGRATION_ERROR_FILE' ) ) {
				@file_put_contents( LEADWERK_MIGRATION_ERROR_FILE, $line, FILE_APPEND );
			}
			if ( ! empty( $params['storage'] ) && is_string( $params['storage'] ) ) {
				Leadwerk_Migration_Log::error( $params['storage'], $payload );
			}
		};
		// #endregion

		// Get upload tmp name
		if ( isset( $_FILES['upload_file']['tmp_name'] ) ) {
			$upload_tmp_name = $_FILES['upload_file']['tmp_name'];
		} else {
			// #region agent log
			$__lw_dbg( 'D', 'missing upload tmp_name', array( 'files_keys' => array_keys( isset( $_FILES['upload_file'] ) && is_array( $_FILES['upload_file'] ) ? $_FILES['upload_file'] : array() ) ) );
			// #endregion
			throw new Leadwerk_Migration_Upload_Exception(
				wp_kses(
					__(
						'The uploaded file is missing a temporary path. The process cannot continue. Review the Leadwerk Migration health report for technical details.',
						'leadwerk-migration'
					),
					leadwerk_migration_allowed_html_tags()
				),
				400
			);
		}

		// Get upload error
		if ( isset( $_FILES['upload_file']['error'] ) ) {
			$upload_error = $_FILES['upload_file']['error'];
		} else {
			// #region agent log
			$__lw_dbg( 'D', 'missing upload error code', array() );
			// #endregion
			throw new Leadwerk_Migration_Upload_Exception(
				wp_kses(
					__(
						'The uploaded file is missing an error code. The process cannot continue. Review the Leadwerk Migration health report for technical details.',
						'leadwerk-migration'
					),
					leadwerk_migration_allowed_html_tags()
				),
				400
			);
		}

		$archive_path   = leadwerk_migration_archive_path( $params );
		$chunk_size     = @filesize( $upload_tmp_name );
		$existing_size  = file_exists( $archive_path ) ? @filesize( $archive_path ) : 0;
		$filename_ok    = leadwerk_migration_is_filename_supported( $archive_path );
		$filedata_ok    = leadwerk_migration_is_filedata_supported( $upload_tmp_name );

		// #region agent log
		$__lw_dbg(
			'A',
			'chunk upload pre-checks',
			array(
				'upload_error'   => (int) $upload_error,
				'chunk_size'     => false === $chunk_size ? null : (int) $chunk_size,
				'existing_size'  => false === $existing_size ? null : (int) $existing_size,
				'filename_ok'    => (bool) $filename_ok,
				'filedata_ok'    => (bool) $filedata_ok,
				'archive_ext'    => pathinfo( $archive_path, PATHINFO_EXTENSION ),
				'is_first_chunk' => empty( $existing_size ),
			)
		);
		// #endregion

		// Verify file extension
		if ( ! $filename_ok ) {
			// #region agent log
			$__lw_dbg( 'E', 'filename rejected', array( 'archive_path_basename' => basename( $archive_path ) ) );
			// #endregion
			throw new Leadwerk_Migration_Upload_Exception(
				wp_kses(
					__(
						'Invalid file type. Please ensure your file is a <strong>.wpress</strong> backup created with Leadwerk Migration. Review the Leadwerk Migration health report for technical details.',
						'leadwerk-migration'
					),
					leadwerk_migration_allowed_html_tags()
				),
				415
			);
		}

		// Verify file data only on the first chunk. Multipart uploads send mid-stream
		// archive bytes after that; the package header exists only at offset 0.
		// Later Import_Validate authenticates the assembled .wpress archive.
		if ( empty( $existing_size ) && ! $filedata_ok ) {
			// #region agent log
			$__lw_dbg(
				'A',
				'filedata rejected on chunk',
				array(
					'chunk_size'    => false === $chunk_size ? null : (int) $chunk_size,
					'existing_size' => false === $existing_size ? null : (int) $existing_size,
					'http_would_be' => 415,
				)
			);
			// #endregion
			throw new Leadwerk_Migration_Upload_Exception(
				wp_kses(
					__(
						'Invalid file data. Please ensure your file is a <strong>.wpress</strong> backup created with Leadwerk Migration. Review the Leadwerk Migration health report for technical details.',
						'leadwerk-migration'
					),
					leadwerk_migration_allowed_html_tags()
				),
				415
			);
		}

		// #region agent log
		if ( ! empty( $existing_size ) ) {
			$__lw_dbg(
				'A',
				'filedata check skipped for continuation chunk',
				array(
					'chunk_size'    => false === $chunk_size ? null : (int) $chunk_size,
					'existing_size' => (int) $existing_size,
					'filedata_ok'   => (bool) $filedata_ok,
				)
			);
		}
		// #endregion

		// Upload file data
		switch ( $upload_error ) {
			case UPLOAD_ERR_OK:
				try {
					leadwerk_migration_copy( $upload_tmp_name, $archive_path );
					leadwerk_migration_unlink( $upload_tmp_name );
					// #region agent log
					$__lw_dbg(
						'C',
						'chunk appended ok',
						array(
							'chunk_size'   => false === $chunk_size ? null : (int) $chunk_size,
							'archive_size' => file_exists( $archive_path ) ? (int) @filesize( $archive_path ) : null,
						)
					);
					// #endregion
				} catch ( Exception $e ) {
					/* translators: Error message. */
					throw new Leadwerk_Migration_Upload_Exception(
						wp_kses(
							sprintf(
								__(
									'Could not upload the file because %s. The process cannot continue. Review the Leadwerk Migration health report for technical details.',
									'leadwerk-migration'
								),
								$e->getMessage()
							),
							leadwerk_migration_allowed_html_tags()
						),
						400
					);
				}

				break;

			case UPLOAD_ERR_INI_SIZE:
			case UPLOAD_ERR_FORM_SIZE:
			case UPLOAD_ERR_PARTIAL:
			case UPLOAD_ERR_NO_FILE:
				throw new Leadwerk_Migration_Upload_Exception(
					wp_kses(
						__(
							'The uploaded file is too large for this server. The process cannot continue. Review the Leadwerk Migration health report for technical details.',
							'leadwerk-migration'
						),
						leadwerk_migration_allowed_html_tags()
					),
					413
				);

			case UPLOAD_ERR_NO_TMP_DIR:
				throw new Leadwerk_Migration_Upload_Exception(
					wp_kses(
						__(
							'No temporary folder is available on the server. The process cannot continue. Review the Leadwerk Migration health report for technical details.',
							'leadwerk-migration'
						),
						leadwerk_migration_allowed_html_tags()
					),
					400
				);

			case UPLOAD_ERR_CANT_WRITE:
				throw new Leadwerk_Migration_Upload_Exception(
					wp_kses(
						__(
							'Could not save the uploaded file. Please check file permissions and try again. Review the Leadwerk Migration health report for technical details.',
							'leadwerk-migration'
						),
						leadwerk_migration_allowed_html_tags()
					),
					400
				);

			case UPLOAD_ERR_EXTENSION:
				throw new Leadwerk_Migration_Upload_Exception(
					wp_kses(
						__(
							'A PHP extension blocked this file upload. The process cannot continue. Review the Leadwerk Migration health report for technical details.',
							'leadwerk-migration'
						),
						leadwerk_migration_allowed_html_tags()
					),
					400
				);

			default:
				/* translators: Error code. */
				throw new Leadwerk_Migration_Upload_Exception(
					wp_kses(
						sprintf(
							__(
								'An unknown error (code: %s) occurred during the file upload. The process cannot continue. Review the Leadwerk Migration health report for technical details.',
								'leadwerk-migration'
							),
							$upload_error
						),
						leadwerk_migration_allowed_html_tags()
					),
					400
				);
		}

		// REST API: return params instead of exit so the handler can build a response
		if ( defined( 'REST_REQUEST' ) && REST_REQUEST ) {
			return $params;
		}

		leadwerk_migration_json_response( array( 'errors' => array() ) );
		exit;
	}
}
