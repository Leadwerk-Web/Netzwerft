<?php
/** Leadwerk Site Sync administration view. */
if ( ! defined( 'ABSPATH' ) ) {
	die( 'Direct access is not allowed.' );
}

$has_family = is_array( $family ) && Leadwerk_Migration_Site_Identity::valid_id( isset( $family['family_id'] ) ? $family['family_id'] : '' );
$registration = isset( $environment['registration'] ) ? $environment['registration'] : 'unregistered';
$approved_environments = array_values(
	array_filter(
		is_array( $directory ) ? $directory : array(),
		static function ( $item ) {
			return is_array( $item ) && isset( $item['status'] ) && 'approved' === $item['status'];
		}
	)
);
$format_seen = static function ( $row ) {
	if ( ! is_array( $row ) || empty( $row['last_seen_at'] ) ) {
		return __( 'Never', 'leadwerk-migration' );
	}
	$timestamp = strtotime( $row['last_seen_at'] . ' UTC' );
	return false === $timestamp ? __( 'Unknown', 'leadwerk-migration' ) : sprintf( __( '%s ago', 'leadwerk-migration' ), human_time_diff( $timestamp, time() ) );
};
$environment_labels = array( 'local' => __( 'Local', 'leadwerk-migration' ), 'staging' => __( 'Staging', 'leadwerk-migration' ), 'live' => __( 'Live', 'leadwerk-migration' ) );
$environment_index = array();
foreach ( is_array( $directory ) ? $directory : array() as $directory_environment ) {
	if ( is_array( $directory_environment ) && ! empty( $directory_environment['environment_id'] ) ) {
		$environment_index[ $directory_environment['environment_id'] ] = $directory_environment;
	}
}
$describe_environment = static function ( $environment_id ) use ( $environment_index, $environment_labels ) {
	if ( isset( $environment_index[ $environment_id ] ) ) {
		$row = $environment_index[ $environment_id ];
		$type = isset( $environment_labels[ $row['environment_type'] ] ) ? $environment_labels[ $row['environment_type'] ] : ucfirst( $row['environment_type'] );
		return $type . ' · ' . $row['site_url'];
	}
	return substr( (string) $environment_id, 0, 8 );
};
$registry_actions = static function ( $kind, $id, $status ) {
	$approve = 'approved' !== $status;
	$action = $approve ? 'leadwerk_migration_hub_approve' : 'leadwerk_migration_hub_revoke';
	ob_start();
	?>
	<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>"><input type="hidden" name="action" value="<?php echo esc_attr( $action ); ?>" /><input type="hidden" name="kind" value="<?php echo esc_attr( $kind ); ?>" /><input type="hidden" name="registry_id" value="<?php echo esc_attr( $id ); ?>" /><?php wp_nonce_field( $action ); ?><button class="button button-small" type="submit"><?php echo esc_html( $approve ? __( 'Reactivate', 'leadwerk-migration' ) : __( 'Emergency revoke', 'leadwerk-migration' ) ); ?></button></form>
	<?php
	return ob_get_clean();
};
?>

<div class="wrap leadwerk-dashboard leadwerk-sync">
	<?php if ( ! empty( $notice['message'] ) ) : ?>
		<div class="notice notice-<?php echo esc_attr( isset( $notice['type'] ) ? $notice['type'] : 'info' ); ?> is-dismissible"><p><?php echo esc_html( $notice['message'] ); ?></p></div>
	<?php endif; ?>
	<?php if ( $remote_error !== '' ) : ?>
		<div class="notice notice-warning"><p><strong><?php esc_html_e( 'Hub connection:', 'leadwerk-migration' ); ?></strong> <?php echo esc_html( $remote_error ); ?></p></div>
	<?php endif; ?>

	<header class="leadwerk-dashboard__hero leadwerk-dashboard__hero--compact">
		<div>
			<p class="leadwerk-dashboard__eyebrow"><?php esc_html_e( 'FULL WORDPRESS ENVIRONMENT TRANSFER', 'leadwerk-migration' ); ?></p>
			<h1><?php esc_html_e( 'Leadwerk Site Sync', 'leadwerk-migration' ); ?></h1>
			<p><?php esc_html_e( 'Identity creation, Hub enrollment and environment activation are automatic. Local, staging and live use signed outbound Hub requests without registration or transfer-approval steps.', 'leadwerk-migration' ); ?></p>
		</div>
		<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
			<input type="hidden" name="action" value="leadwerk_migration_sync_process" />
			<?php wp_nonce_field( 'leadwerk_migration_sync_process' ); ?>
			<button class="button button-primary" type="submit" <?php disabled( ! $has_family || 'approved' !== $registration ); ?>><?php esc_html_e( 'Run worker now', 'leadwerk-migration' ); ?></button>
		</form>
	</header>

	<div class="leadwerk-dashboard__metrics">
		<div class="leadwerk-metric"><span><?php esc_html_e( 'This environment', 'leadwerk-migration' ); ?></span><strong><?php echo esc_html( isset( $environment_labels[ $environment['type'] ] ) ? $environment_labels[ $environment['type'] ] : ucfirst( $environment['type'] ) ); ?></strong><small><?php echo esc_html( Leadwerk_Migration_Site_Identity::normalized_site_url() ); ?></small></div>
		<div class="leadwerk-metric"><span><?php esc_html_e( 'Runtime versions', 'leadwerk-migration' ); ?></span><strong><?php echo esc_html( get_bloginfo( 'version' ) ); ?></strong><small><?php echo esc_html( 'PHP ' . PHP_VERSION . ' · Plugin ' . LEADWERK_MIGRATION_VERSION ); ?></small></div>
		<div class="leadwerk-metric"><span><?php esc_html_e( 'Hub enrollment', 'leadwerk-migration' ); ?></span><strong class="leadwerk-state <?php echo 'approved' === $registration ? 'is-active' : ''; ?>"><?php echo esc_html( 'approved' === $registration ? __( 'Active', 'leadwerk-migration' ) : __( 'Automatic retry', 'leadwerk-migration' ) ); ?></strong><small><?php echo esc_html( $settings['hub_url'] ); ?></small></div>
	</div>

	<?php if ( ! $has_family ) : ?>
		<section class="leadwerk-panel leadwerk-panel--zone-zero">
			<div class="leadwerk-panel__header"><div><h2><?php esc_html_e( 'Automatic identity enrollment', 'leadwerk-migration' ); ?></h2><p><?php esc_html_e( 'Identity creation does not require a backup. Use retry only when the Hub was unavailable during automatic enrollment.', 'leadwerk-migration' ); ?></p></div><span class="leadwerk-badge leadwerk-badge--warning"><?php esc_html_e( 'Retry required', 'leadwerk-migration' ); ?></span></div>
			<form class="leadwerk-settings leadwerk-sync__inline-form" method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
				<input type="hidden" name="action" value="leadwerk_migration_sync_initialize" />
				<?php wp_nonce_field( 'leadwerk_migration_sync_initialize' ); ?>
				<label><span><?php esc_html_e( 'Project name', 'leadwerk-migration' ); ?></span><input type="text" name="project_name" maxlength="190" value="<?php echo esc_attr( get_bloginfo( 'name' ) ); ?>" required /></label>
				<button class="button button-primary" type="submit"><?php esc_html_e( 'Retry automatic enrollment', 'leadwerk-migration' ); ?></button>
			</form>
		</section>
	<?php else : ?>
		<div class="leadwerk-dashboard__grid leadwerk-dashboard__grid--sync">
			<section class="leadwerk-panel">
				<div class="leadwerk-panel__header"><div><h2><?php esc_html_e( 'Site Family identity', 'leadwerk-migration' ); ?></h2><p><?php esc_html_e( 'Secrets are never shown in the browser. Each environment has its own credential.', 'leadwerk-migration' ); ?></p></div><span class="leadwerk-badge leadwerk-badge--verified"><?php esc_html_e( 'Zone Zero linked', 'leadwerk-migration' ); ?></span></div>
				<dl class="leadwerk-status-list">
					<div><dt><?php esc_html_e( 'Project', 'leadwerk-migration' ); ?></dt><dd><?php echo esc_html( isset( $family['project_name'] ) ? $family['project_name'] : '' ); ?></dd></div>
					<div><dt><?php esc_html_e( 'Family ID', 'leadwerk-migration' ); ?></dt><dd><code><?php echo esc_html( $family['family_id'] ); ?></code></dd></div>
					<div><dt><?php esc_html_e( 'Environment ID', 'leadwerk-migration' ); ?></dt><dd><code><?php echo esc_html( $environment['environment_id'] ); ?></code></dd></div>
					<?php if ( ! empty( $environment['promoted_at'] ) ) : ?><div><dt><?php esc_html_e( 'Promoted to live', 'leadwerk-migration' ); ?></dt><dd><?php echo esc_html( $environment['promoted_at'] ); ?></dd></div><?php endif; ?>
					<div><dt><?php esc_html_e( 'Heartbeat', 'leadwerk-migration' ); ?></dt><dd><?php esc_html_e( 'Every 5 minutes; offline after 15 minutes', 'leadwerk-migration' ); ?></dd></div>
				</dl>
				<div class="leadwerk-callout"><strong><?php esc_html_e( 'WP-Cron note', 'leadwerk-migration' ); ?></strong><p><?php esc_html_e( 'WordPress cron needs site traffic. Configure the host to call wp-cron.php every five minutes when exact online monitoring is required.', 'leadwerk-migration' ); ?></p></div>
				<?php if ( isset( $environment['type'] ) && 'staging' === $environment['type'] ) : ?>
					<div class="leadwerk-sync__promotion">
						<h3><?php esc_html_e( 'Promote this staging installation', 'leadwerk-migration' ); ?></h3>
						<p><?php esc_html_e( 'Use this when the customer domain is now attached but automatic detection cannot identify the change. The environment ID and sync history are preserved.', 'leadwerk-migration' ); ?></p>
						<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
							<input type="hidden" name="action" value="leadwerk_migration_sync_promote_live" /><?php wp_nonce_field( 'leadwerk_migration_sync_promote_live' ); ?>
							<label><span><?php esc_html_e( 'Enter PROMOTE LIVE', 'leadwerk-migration' ); ?></span><input type="text" name="promotion_confirmation" autocomplete="off" required /></label>
							<button class="button" type="submit"><?php esc_html_e( 'Promote staging to live', 'leadwerk-migration' ); ?></button>
						</form>
					</div>
				<?php endif; ?>
			</section>
			<aside class="leadwerk-panel leadwerk-panel--quick">
				<div class="leadwerk-panel__header"><div><h2><?php esc_html_e( 'Zero-touch Hub connection', 'leadwerk-migration' ); ?></h2><p><?php esc_html_e( 'The family secret proves membership. Heartbeat automatically creates and activates this environment in Hub; no Hub administrator approval is requested.', 'leadwerk-migration' ); ?></p></div><span class="leadwerk-badge <?php echo 'approved' === $registration ? 'leadwerk-badge--verified' : 'leadwerk-badge--warning'; ?>"><?php echo esc_html( 'approved' === $registration ? __( 'Automatic', 'leadwerk-migration' ) : __( 'Retrying', 'leadwerk-migration' ) ); ?></span></div>
				<ul class="leadwerk-feature-list"><li><?php esc_html_e( 'No Zone Zero backup required for identity', 'leadwerk-migration' ); ?></li><li><?php esc_html_e( 'No manual environment registration', 'leadwerk-migration' ); ?></li><li><?php esc_html_e( 'No family/environment approval', 'leadwerk-migration' ); ?></li><li><?php esc_html_e( 'No source/target transfer approval', 'leadwerk-migration' ); ?></li></ul>
			</aside>
		</div>
	<?php endif; ?>

	<section class="leadwerk-panel">
		<div class="leadwerk-panel__header"><div><h2><?php esc_html_e( 'Environments and heartbeat', 'leadwerk-migration' ); ?></h2><p><?php esc_html_e( 'All environments ping Leadwerk Hub every five minutes. Direct environment-to-environment network access is not used.', 'leadwerk-migration' ); ?></p></div><span class="leadwerk-badge"><?php echo esc_html( sprintf( __( '%d environments', 'leadwerk-migration' ), count( $directory ) ) ); ?></span></div>
		<?php if ( $directory ) : ?>
			<div class="leadwerk-table-wrap"><table class="widefat striped leadwerk-table"><thead><tr><th><?php esc_html_e( 'Environment', 'leadwerk-migration' ); ?></th><th><?php esc_html_e( 'Status', 'leadwerk-migration' ); ?></th><th><?php esc_html_e( 'Last heartbeat', 'leadwerk-migration' ); ?></th><th><?php esc_html_e( 'WordPress', 'leadwerk-migration' ); ?></th><th><?php esc_html_e( 'PHP', 'leadwerk-migration' ); ?></th><th><?php esc_html_e( 'Plugin', 'leadwerk-migration' ); ?></th></tr></thead><tbody>
			<?php foreach ( $directory as $item ) : ?>
				<tr><td><strong><?php echo esc_html( isset( $environment_labels[ $item['environment_type'] ] ) ? $environment_labels[ $item['environment_type'] ] : ucfirst( $item['environment_type'] ) ); ?></strong><br /><small><?php echo esc_html( $item['site_url'] ); ?></small></td><td><span class="leadwerk-badge <?php echo ! empty( $item['is_online'] ) ? 'leadwerk-badge--verified' : 'leadwerk-badge--modified'; ?>"><span class="leadwerk-state-dot <?php echo empty( $item['is_online'] ) ? 'is-offline' : ''; ?>"></span><?php echo esc_html( ! empty( $item['is_online'] ) ? __( 'Online', 'leadwerk-migration' ) : __( 'Offline', 'leadwerk-migration' ) ); ?></span></td><td><?php echo esc_html( $format_seen( $item ) ); ?></td><td><?php echo esc_html( $item['wordpress_version'] ); ?></td><td><?php echo esc_html( $item['php_version'] ); ?></td><td><?php echo esc_html( $item['plugin_version'] ); ?></td></tr>
			<?php endforeach; ?>
			</tbody></table></div>
		<?php else : ?><div class="leadwerk-empty"><span class="dashicons dashicons-admin-site-alt3" aria-hidden="true"></span><h3><?php esc_html_e( 'Waiting for environment heartbeats', 'leadwerk-migration' ); ?></h3><p><?php esc_html_e( 'Sibling environments appear automatically after a cloned installation contacts Hub. No registration or approval action is needed.', 'leadwerk-migration' ); ?></p></div><?php endif; ?>
	</section>

	<section class="leadwerk-panel leadwerk-sync__runtime">
		<div class="leadwerk-panel__header"><div><h2><?php esc_html_e( 'Reconcile runtime versions', 'leadwerk-migration' ); ?></h2><p><?php esc_html_e( 'Use a current environment as reference. Hub first publishes its current Leadwerk Migration package, then the target requests the exact WordPress and PHP versions.', 'leadwerk-migration' ); ?></p></div><span class="leadwerk-badge leadwerk-badge--warning"><?php esc_html_e( 'One-time 1.3 bootstrap required', 'leadwerk-migration' ); ?></span></div>
		<form class="leadwerk-settings" method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
			<input type="hidden" name="action" value="leadwerk_migration_runtime_reconcile" /><?php wp_nonce_field( 'leadwerk_migration_runtime_reconcile' ); ?>
			<div class="leadwerk-sync__direction">
				<label><span><?php esc_html_e( 'Reference runtime', 'leadwerk-migration' ); ?></span><select name="reference_environment_id" required><option value=""><?php esc_html_e( 'Choose reference', 'leadwerk-migration' ); ?></option><?php foreach ( $approved_environments as $item ) : ?><option value="<?php echo esc_attr( $item['environment_id'] ); ?>"><?php echo esc_html( strtoupper( $item['environment_type'] ) . ' · WP ' . $item['wordpress_version'] . ' · PHP ' . $item['php_version'] . ' · Plugin ' . $item['plugin_version'] ); ?></option><?php endforeach; ?></select></label>
				<span class="dashicons dashicons-update" aria-hidden="true"></span>
				<label><span><?php esc_html_e( 'Environment to update', 'leadwerk-migration' ); ?></span><select name="target_environment_id" required><option value=""><?php esc_html_e( 'Choose target', 'leadwerk-migration' ); ?></option><?php foreach ( $approved_environments as $item ) : ?><option value="<?php echo esc_attr( $item['environment_id'] ); ?>"><?php echo esc_html( strtoupper( $item['environment_type'] ) . ' · ' . $item['site_url'] ); ?></option><?php endforeach; ?></select></label>
			</div>
			<div class="leadwerk-callout"><strong><?php esc_html_e( 'Update sequence', 'leadwerk-migration' ); ?></strong><p><?php esc_html_e( 'Leadwerk Migration is downloaded from Hub and SHA-256 verified. WordPress uses the official core updater and only upgrades to an exact offered version. PHP requires a hosting connector; WordPress cannot replace the server runtime itself.', 'leadwerk-migration' ); ?></p></div>
			<div class="leadwerk-settings__footer"><button class="button" type="submit" <?php disabled( count( $approved_environments ) < 2 ); ?>><?php esc_html_e( 'Queue runtime reconciliation', 'leadwerk-migration' ); ?></button></div>
		</form>
	</section>

	<section class="leadwerk-panel leadwerk-sync__transfer">
		<div class="leadwerk-panel__header"><div><h2><?php esc_html_e( 'Start full-site synchronization', 'leadwerk-migration' ); ?></h2><p><?php esc_html_e( 'Database, uploads/media, plugins, themes and MU plugins move from source to target. WordPress core, PHP, wp-config.php, DNS, SSL and hosting configuration are not transferred.', 'leadwerk-migration' ); ?></p></div><span class="leadwerk-badge leadwerk-badge--warning"><?php esc_html_e( 'Replaces target site data', 'leadwerk-migration' ); ?></span></div>
		<form class="leadwerk-settings" id="leadwerk-sync-transfer" method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
			<input type="hidden" name="action" value="leadwerk_migration_sync_request" />
			<?php wp_nonce_field( 'leadwerk_migration_sync_request' ); ?>
			<div class="leadwerk-sync__direction">
				<label><span><?php esc_html_e( 'Source (will be backed up)', 'leadwerk-migration' ); ?></span><select name="source_environment_id" required><option value=""><?php esc_html_e( 'Choose source', 'leadwerk-migration' ); ?></option><?php foreach ( $approved_environments as $item ) : ?><option value="<?php echo esc_attr( $item['environment_id'] ); ?>" data-environment-type="<?php echo esc_attr( $item['environment_type'] ); ?>"><?php echo esc_html( strtoupper( $item['environment_type'] ) . ' · ' . $item['site_url'] ); ?></option><?php endforeach; ?></select></label>
				<span class="dashicons dashicons-arrow-right-alt" aria-hidden="true"></span>
				<label><span><?php esc_html_e( 'Target (will be replaced)', 'leadwerk-migration' ); ?></span><select name="target_environment_id" required><option value=""><?php esc_html_e( 'Choose target', 'leadwerk-migration' ); ?></option><?php foreach ( $approved_environments as $item ) : ?><option value="<?php echo esc_attr( $item['environment_id'] ); ?>" data-environment-type="<?php echo esc_attr( $item['environment_type'] ); ?>"><?php echo esc_html( strtoupper( $item['environment_type'] ) . ' · ' . $item['site_url'] ); ?></option><?php endforeach; ?></select></label>
			</div>
			<div class="leadwerk-sync__preflight"><strong><?php esc_html_e( 'Mandatory preflight order', 'leadwerk-migration' ); ?></strong><ol><li><?php esc_html_e( 'Exact WordPress version', 'leadwerk-migration' ); ?></li><li><?php esc_html_e( 'Exact PHP version', 'leadwerk-migration' ); ?></li><li><?php esc_html_e( 'Exact plugin version', 'leadwerk-migration' ); ?></li><li><?php esc_html_e( 'Both heartbeats newer than 15 minutes', 'leadwerk-migration' ); ?></li></ol></div>
			<div class="leadwerk-callout"><strong><?php esc_html_e( 'Automatic target protection', 'leadwerk-migration' ); ?></strong><p><?php esc_html_e( 'Starting the job first checks exact versions and fresh heartbeats, then creates a target safety backup and verifies the received archive with SHA-256 before import.', 'leadwerk-migration' ); ?></p></div>
			<div class="leadwerk-settings__footer"><button class="button button-primary" type="submit" <?php disabled( count( $approved_environments ) < 2 ); ?>><?php esc_html_e( 'Start full-site sync', 'leadwerk-migration' ); ?></button></div>
		</form>
	</section>

	<section class="leadwerk-panel">
		<div class="leadwerk-panel__header"><div><h2><?php esc_html_e( 'Synchronization jobs', 'leadwerk-migration' ); ?></h2><p><?php esc_html_e( 'Transfers resume in encrypted, signed outbound batches. The Hub relay copy expires automatically.', 'leadwerk-migration' ); ?></p></div></div>
		<?php if ( $jobs ) : ?><div class="leadwerk-table-wrap"><table class="widefat striped leadwerk-table"><thead><tr><th><?php esc_html_e( 'Created', 'leadwerk-migration' ); ?></th><th><?php esc_html_e( 'Direction', 'leadwerk-migration' ); ?></th><th><?php esc_html_e( 'Status', 'leadwerk-migration' ); ?></th><th><?php esc_html_e( 'Progress', 'leadwerk-migration' ); ?></th><th><?php esc_html_e( 'Message', 'leadwerk-migration' ); ?></th><th><?php esc_html_e( 'Manage', 'leadwerk-migration' ); ?></th></tr></thead><tbody>
		<?php foreach ( $jobs as $job ) : $size = isset( $job['archive_size'] ) ? (int) $job['archive_size'] : 0; $received = isset( $job['bytes_received'] ) ? (int) $job['bytes_received'] : 0; ?>
			<tr><td><?php echo esc_html( isset( $job['created_at'] ) ? $job['created_at'] . ' UTC' : '' ); ?></td><td><?php echo esc_html( $describe_environment( $job['source_environment_id'] ) ); ?> → <?php echo esc_html( $describe_environment( $job['target_environment_id'] ) ); ?></td><td><span class="leadwerk-badge leadwerk-badge--<?php echo esc_attr( sanitize_html_class( $job['status'] ) ); ?>"><?php echo esc_html( ucwords( str_replace( '_', ' ', $job['status'] ) ) ); ?></span></td><td><?php echo $size > 0 ? esc_html( size_format( $received ) . ' / ' . size_format( $size ) ) : '—'; ?></td><td><?php echo esc_html( isset( $job['message'] ) ? $job['message'] : '' ); ?></td><td class="leadwerk-table__actions"><?php if ( in_array( $job['status'], array( 'approved', 'transferring', 'ready', 'receiving', 'failed' ), true ) ) : ?><form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>"><input type="hidden" name="action" value="leadwerk_migration_sync_cancel_job" /><input type="hidden" name="job_id" value="<?php echo esc_attr( $job['job_id'] ); ?>" /><?php wp_nonce_field( 'leadwerk_migration_sync_cancel_job' ); ?><button class="button-link" type="submit"><?php esc_html_e( 'Cancel', 'leadwerk-migration' ); ?></button></form><?php endif; ?><?php if ( in_array( $job['status'], array( 'failed', 'canceled' ), true ) ) : ?><form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>"><input type="hidden" name="action" value="leadwerk_migration_sync_retry_job" /><input type="hidden" name="job_id" value="<?php echo esc_attr( $job['job_id'] ); ?>" /><?php wp_nonce_field( 'leadwerk_migration_sync_retry_job' ); ?><button class="button-link" type="submit"><?php esc_html_e( 'Retry', 'leadwerk-migration' ); ?></button></form><?php endif; ?></td></tr>
		<?php endforeach; ?></tbody></table></div><?php else : ?><div class="leadwerk-empty"><span class="dashicons dashicons-randomize" aria-hidden="true"></span><h3><?php esc_html_e( 'No sync jobs', 'leadwerk-migration' ); ?></h3><p><?php esc_html_e( 'Jobs appear here after the first version-compatible transfer is requested.', 'leadwerk-migration' ); ?></p></div><?php endif; ?>
	</section>

	<section class="leadwerk-panel">
		<div class="leadwerk-panel__header"><div><h2><?php esc_html_e( 'Runtime update jobs', 'leadwerk-migration' ); ?></h2><p><?php esc_html_e( 'Every Site Family member sees the same update history and current stage.', 'leadwerk-migration' ); ?></p></div></div>
		<?php if ( $commands ) : ?><div class="leadwerk-table-wrap"><table class="widefat striped leadwerk-table"><thead><tr><th><?php esc_html_e( 'Created', 'leadwerk-migration' ); ?></th><th><?php esc_html_e( 'Target', 'leadwerk-migration' ); ?></th><th><?php esc_html_e( 'Desired runtime', 'leadwerk-migration' ); ?></th><th><?php esc_html_e( 'Stage', 'leadwerk-migration' ); ?></th><th><?php esc_html_e( 'Status', 'leadwerk-migration' ); ?></th><th><?php esc_html_e( 'Message', 'leadwerk-migration' ); ?></th><th><?php esc_html_e( 'Manage', 'leadwerk-migration' ); ?></th></tr></thead><tbody><?php foreach ( $commands as $command ) : $command_payload = isset( $command['payload'] ) && is_array( $command['payload'] ) ? $command['payload'] : array(); ?><tr><td><?php echo esc_html( $command['created_at'] . ' UTC' ); ?></td><td><?php echo esc_html( $describe_environment( $command['target_environment_id'] ) ); ?></td><td><?php echo esc_html( 'WP ' . ( isset( $command_payload['wordpress_version'] ) ? $command_payload['wordpress_version'] : '—' ) . ' · PHP ' . ( isset( $command_payload['php_version'] ) ? $command_payload['php_version'] : '—' ) . ' · Plugin ' . ( isset( $command_payload['plugin_version'] ) ? $command_payload['plugin_version'] : '—' ) ); ?></td><td><?php echo esc_html( isset( $command_payload['stage'] ) ? ucfirst( $command_payload['stage'] ) : '—' ); ?></td><td><span class="leadwerk-badge leadwerk-badge--<?php echo esc_attr( sanitize_html_class( $command['status'] ) ); ?>"><?php echo esc_html( ucwords( str_replace( '_', ' ', $command['status'] ) ) ); ?></span></td><td><?php echo esc_html( $command['message'] ); ?></td><td class="leadwerk-table__actions"><?php if ( in_array( $command['status'], array( 'queued', 'running', 'waiting_runtime' ), true ) ) : ?><form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>"><input type="hidden" name="action" value="leadwerk_migration_runtime_cancel_command" /><input type="hidden" name="command_id" value="<?php echo esc_attr( $command['command_id'] ); ?>" /><?php wp_nonce_field( 'leadwerk_migration_runtime_cancel_command' ); ?><button class="button-link" type="submit"><?php esc_html_e( 'Cancel', 'leadwerk-migration' ); ?></button></form><?php endif; ?><?php if ( in_array( $command['status'], array( 'failed', 'canceled', 'manual_required' ), true ) ) : ?><form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>"><input type="hidden" name="action" value="leadwerk_migration_runtime_retry_command" /><input type="hidden" name="command_id" value="<?php echo esc_attr( $command['command_id'] ); ?>" /><?php wp_nonce_field( 'leadwerk_migration_runtime_retry_command' ); ?><button class="button-link" type="submit"><?php esc_html_e( 'Retry', 'leadwerk-migration' ); ?></button></form><?php endif; ?></td></tr><?php endforeach; ?></tbody></table></div><?php else : ?><div class="leadwerk-empty"><span class="dashicons dashicons-update" aria-hidden="true"></span><h3><?php esc_html_e( 'No runtime update jobs', 'leadwerk-migration' ); ?></h3></div><?php endif; ?>
	</section>

	<section class="leadwerk-panel">
		<div class="leadwerk-panel__header"><div><h2><?php esc_html_e( 'Site Sync settings', 'leadwerk-migration' ); ?></h2><p><?php esc_html_e( 'Automatic detection treats .local as local and myrdbx.io as staging. When the same installation receives a normal customer domain, its identity is preserved and its Hub type changes to live.', 'leadwerk-migration' ); ?></p></div></div>
		<form class="leadwerk-settings" method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
			<input type="hidden" name="action" value="leadwerk_migration_sync_save" /><?php wp_nonce_field( 'leadwerk_migration_sync_save' ); ?>
			<div class="leadwerk-field-grid">
				<label><span><?php esc_html_e( 'Project name', 'leadwerk-migration' ); ?></span><input type="text" name="project_name" maxlength="190" value="<?php echo esc_attr( isset( $family['project_name'] ) ? $family['project_name'] : get_bloginfo( 'name' ) ); ?>" /></label>
				<label><span><?php esc_html_e( 'Leadwerk Hub URL', 'leadwerk-migration' ); ?></span><input type="url" name="settings[hub_url]" value="<?php echo esc_attr( $settings['hub_url'] ); ?>" required /></label>
				<label><span><?php esc_html_e( 'Environment type', 'leadwerk-migration' ); ?></span><select name="settings[environment_type]"><?php foreach ( array( 'auto' => __( 'Automatic', 'leadwerk-migration' ), 'local' => __( 'Local', 'leadwerk-migration' ), 'staging' => __( 'Staging', 'leadwerk-migration' ), 'live' => __( 'Live', 'leadwerk-migration' ) ) as $value => $label ) : ?><option value="<?php echo esc_attr( $value ); ?>" <?php selected( $settings['environment_type'], $value ); ?>><?php echo esc_html( $label ); ?></option><?php endforeach; ?></select></label>
				<label><span><?php esc_html_e( 'Relay retention (hours)', 'leadwerk-migration' ); ?></span><input type="number" min="1" max="168" name="settings[relay_retention_hours]" value="<?php echo esc_attr( $settings['relay_retention_hours'] ); ?>" /></label>
				<label><span><?php esc_html_e( 'Hosting PHP update webhook (optional)', 'leadwerk-migration' ); ?></span><input type="url" name="settings[php_update_webhook_url]" value="<?php echo esc_attr( isset( $settings['php_update_webhook_url'] ) ? $settings['php_update_webhook_url'] : '' ); ?>" placeholder="https://hosting.example/update-php" /></label>
				<label><span><?php esc_html_e( 'PHP webhook HMAC secret', 'leadwerk-migration' ); ?></span><input type="password" name="settings[php_update_webhook_secret]" value="" placeholder="<?php echo ! empty( $settings['php_update_webhook_secret'] ) ? esc_attr__( 'Saved — leave blank to keep', 'leadwerk-migration' ) : ''; ?>" autocomplete="new-password" /></label>
			</div>
			<fieldset class="leadwerk-fieldset"><legend><?php esc_html_e( 'Central Hub role', 'leadwerk-migration' ); ?></legend><label><input type="hidden" name="settings[hub_mode]" value="0" /><input type="checkbox" name="settings[hub_mode]" value="1" <?php checked( ! empty( $settings['hub_mode'] ) ); ?> /> <?php esc_html_e( 'Enable registry and private relay on this WordPress (intended for leadwerk.de)', 'leadwerk-migration' ); ?></label><p><?php esc_html_e( 'When enabling for the first time, enter ENABLE HUB. Valid cryptographic family/environment proofs are activated automatically; the registry retains emergency revoke controls.', 'leadwerk-migration' ); ?></p><input type="text" name="hub_confirmation" placeholder="ENABLE HUB" autocomplete="off" /></fieldset>
			<div class="leadwerk-settings__footer"><button class="button button-primary" type="submit"><?php esc_html_e( 'Save settings', 'leadwerk-migration' ); ?></button></div>
		</form>
	</section>

	<?php if ( ! empty( $settings['hub_mode'] ) ) : ?>
		<section class="leadwerk-panel leadwerk-sync__hub-admin">
			<div class="leadwerk-panel__header"><div><h2><?php esc_html_e( 'Leadwerk Hub registry', 'leadwerk-migration' ); ?></h2><p><?php esc_html_e( 'Families and environments with valid secret proofs activate automatically. Controls below are only for emergency revocation or reactivation.', 'leadwerk-migration' ); ?></p></div><span class="leadwerk-badge leadwerk-badge--verified"><?php esc_html_e( 'Zero-touch Hub mode', 'leadwerk-migration' ); ?></span></div>
			<h3><?php esc_html_e( 'Site Families', 'leadwerk-migration' ); ?></h3>
			<div class="leadwerk-table-wrap"><table class="widefat striped leadwerk-table"><thead><tr><th><?php esc_html_e( 'Project', 'leadwerk-migration' ); ?></th><th><?php esc_html_e( 'Family ID', 'leadwerk-migration' ); ?></th><th><?php esc_html_e( 'Status', 'leadwerk-migration' ); ?></th><th></th></tr></thead><tbody><?php foreach ( $hub_data['families'] as $item ) : ?><tr><td><?php echo esc_html( $item['project_name'] ); ?></td><td><code><?php echo esc_html( $item['family_id'] ); ?></code></td><td><?php echo esc_html( 'approved' === $item['status'] ? __( 'Active', 'leadwerk-migration' ) : ucfirst( $item['status'] ) ); ?></td><td><?php echo $registry_actions( 'family', $item['family_id'], $item['status'] ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?></td></tr><?php endforeach; ?></tbody></table></div>
			<h3><?php esc_html_e( 'Environments', 'leadwerk-migration' ); ?></h3>
			<div class="leadwerk-table-wrap"><table class="widefat striped leadwerk-table"><thead><tr><th><?php esc_html_e( 'URL', 'leadwerk-migration' ); ?></th><th><?php esc_html_e( 'Type', 'leadwerk-migration' ); ?></th><th><?php esc_html_e( 'Heartbeat', 'leadwerk-migration' ); ?></th><th><?php esc_html_e( 'Versions', 'leadwerk-migration' ); ?></th><th><?php esc_html_e( 'Status', 'leadwerk-migration' ); ?></th><th></th></tr></thead><tbody><?php foreach ( $hub_data['environments'] as $item ) : ?><tr><td><?php echo esc_html( $item['site_url'] ); ?></td><td><?php echo esc_html( $item['environment_type'] ); ?></td><td><span class="leadwerk-badge <?php echo ! empty( $item['is_online'] ) ? 'leadwerk-badge--verified' : 'leadwerk-badge--modified'; ?>"><?php echo esc_html( ! empty( $item['is_online'] ) ? __( 'Online', 'leadwerk-migration' ) : __( 'Offline', 'leadwerk-migration' ) ); ?></span> <?php echo esc_html( $format_seen( $item ) ); ?></td><td><?php echo esc_html( 'WP ' . $item['wordpress_version'] . ' · PHP ' . $item['php_version'] . ' · ' . $item['plugin_version'] ); ?></td><td><?php echo esc_html( 'approved' === $item['status'] ? __( 'Active', 'leadwerk-migration' ) : ucfirst( $item['status'] ) ); ?></td><td><?php echo $registry_actions( 'environment', $item['environment_id'], $item['status'] ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?></td></tr><?php endforeach; ?></tbody></table></div>
		</section>
	<?php endif; ?>
</div>
