<?php
/**
 * Translation settings and safe clone workflow.
 *
 * @package Leadwerk_WPML_Clone
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class Leadwerk_Translation_Admin {
	private static $syncing = false;

	public static function init() {
		add_action( 'admin_menu', array( __CLASS__, 'menu' ) );
		add_action( 'admin_init', array( __CLASS__, 'save_settings' ) );
		add_action( 'admin_bar_menu', array( __CLASS__, 'admin_bar' ), 90 );
		add_action( 'add_meta_boxes_page', array( __CLASS__, 'metabox' ) );
		add_action( 'save_post_page', array( __CLASS__, 'mark_counterpart_for_review' ), 30, 3 );
		add_action( 'admin_post_leadwerk_clone_english', array( __CLASS__, 'clone_action' ) );
		add_action( 'admin_post_leadwerk_clone_all_english', array( __CLASS__, 'clone_all_action' ) );
		add_shortcode( 'leadwerk_language_switcher', array( __CLASS__, 'switcher_shortcode' ) );
	}

	public static function menu() {
		add_options_page(
			'Leadwerk Sprachen',
			'Leadwerk Sprachen',
			'manage_options',
			'leadwerk-languages',
			array( __CLASS__, 'settings_page' )
		);
	}

	public static function settings_page() {
		if ( ! current_user_can( 'manage_options' ) ) {
			return;
		}
		$active = Leadwerk_Translation_API::active_languages();
		?>
		<div class="wrap">
			<h1>Leadwerk Sprachen</h1>
			<p>Deutsch ist die einzige aktive Standardsprache. Englisch erzeugt erst nach Aktivierung und manuellem Klonen öffentliche Routen.</p>
			<p><a class="button" href="<?php echo esc_url( admin_url( 'admin.php?page=leadwerk-translations' ) ); ?>">Translation Dashboard öffnen</a></p>
			<form method="post">
				<?php wp_nonce_field( 'leadwerk_languages_save', 'leadwerk_languages_nonce' ); ?>
				<input type="hidden" name="leadwerk_languages_submit" value="1">
				<p><label><input type="checkbox" checked disabled> Deutsch (Standard)</label></p>
				<p><label><input type="checkbox" name="leadwerk_enable_en" value="1" <?php checked( in_array( 'en', $active, true ) ); ?>> Englisch aktivieren</label></p>
				<?php submit_button(); ?>
			</form>
		</div>
		<?php
	}

	/** Display all page pairs and their current translation state. */
	public static function dashboard_page() {
		if ( ! current_user_can( 'edit_pages' ) ) {
			wp_die( esc_html__( 'Keine Berechtigung.', 'leadwerk-wpml-clone' ), '', array( 'response' => 403 ) );
		}

		$pages      = self::source_pages();
		$translated = 0;
		$review     = 0;
		foreach ( $pages as $page ) {
			$english_id = Leadwerk_Translation_API::get_counterpart( $page->ID, 'en' );
			if ( $english_id ) {
				$translated++;
				if ( 'needs_review' === get_post_meta( $english_id, '_leadwerk_translation_status', true ) ) {
					$review++;
				}
			}
		}

		// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only result notice.
		$created = isset( $_GET['created'] ) ? absint( $_GET['created'] ) : 0;
		// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only result notice.
		$failed = isset( $_GET['failed'] ) ? absint( $_GET['failed'] ) : 0;
		?>
		<div class="wrap leadwerk-translations">
			<h1>Translation Dashboard</h1>
			<p>Deutsch bleibt die Quelle. Englische Seiten werden als Entwurf erstellt und erst nach redaktioneller Prüfung veröffentlicht.</p>
			<?php if ( $created || $failed ) : ?>
				<div class="notice <?php echo $failed ? 'notice-warning' : 'notice-success'; ?> is-dismissible"><p><?php echo esc_html( sprintf( '%d EN-Entwürfe erstellt, %d fehlgeschlagen.', $created, $failed ) ); ?></p></div>
			<?php endif; ?>
			<div style="display:flex;gap:12px;flex-wrap:wrap;margin:18px 0">
				<div class="card" style="min-width:170px;margin:0"><h2 style="margin-top:0">DE Seiten</h2><strong style="font-size:28px"><?php echo esc_html( count( $pages ) ); ?></strong></div>
				<div class="card" style="min-width:170px;margin:0"><h2 style="margin-top:0">EN vorhanden</h2><strong style="font-size:28px"><?php echo esc_html( $translated ); ?></strong></div>
				<div class="card" style="min-width:170px;margin:0"><h2 style="margin-top:0">Prüfung nötig</h2><strong style="font-size:28px"><?php echo esc_html( $review ); ?></strong></div>
			</div>
			<div style="display:flex;align-items:center;gap:6px;flex-wrap:wrap;margin:16px 0">
				<?php if ( current_user_can( 'manage_options' ) ) : ?><a class="button" href="<?php echo esc_url( admin_url( 'admin.php?page=leadwerk-languages' ) ); ?>">Spracheinstellungen</a><?php endif; ?>
				<?php if ( current_user_can( 'manage_options' ) && Leadwerk_Translation_API::is_active( 'en' ) && $translated < count( $pages ) ) : ?>
					<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
						<input type="hidden" name="action" value="leadwerk_clone_all_english">
						<?php wp_nonce_field( 'leadwerk_clone_all_english' ); ?>
						<button type="submit" class="button button-primary">Fehlende EN-Entwürfe erstellen</button>
					</form>
				<?php endif; ?>
			</div>
			<table class="widefat striped" style="margin-top:16px">
				<thead><tr><th>Deutsche Seite</th><th>DE Status</th><th>Englische Seite</th><th>Übersetzungsstatus</th><th>Aktionen</th></tr></thead>
				<tbody>
				<?php if ( ! $pages ) : ?>
					<tr><td colspan="5">Keine Seiten gefunden.</td></tr>
				<?php endif; ?>
				<?php foreach ( $pages as $page ) : ?>
					<?php
					$english_id     = Leadwerk_Translation_API::get_counterpart( $page->ID, 'en' );
					$english_status = $english_id ? get_post_status( $english_id ) : '';
					$translation    = $english_id ? sanitize_key( (string) get_post_meta( $english_id, '_leadwerk_translation_status', true ) ) : 'missing';
					$translation    = $translation ? $translation : 'not_translated';
					$clone_url      = wp_nonce_url( admin_url( 'admin-post.php?action=leadwerk_clone_english&post_id=' . $page->ID ), 'leadwerk_clone_english_' . $page->ID );
					?>
					<tr>
						<td><strong><a href="<?php echo esc_url( get_edit_post_link( $page->ID ) ); ?>"><?php echo esc_html( get_the_title( $page ) ); ?></a></strong><br><code><?php echo esc_html( Leadwerk_Translation_API::group_of( $page->ID ) ); ?></code></td>
						<td><?php echo esc_html( self::post_status_label( get_post_status( $page ) ) ); ?></td>
						<td><?php if ( $english_id ) : ?><a href="<?php echo esc_url( get_edit_post_link( $english_id ) ); ?>"><?php echo esc_html( get_the_title( $english_id ) ); ?></a><?php else : ?><span aria-hidden="true">—</span><span class="screen-reader-text">Nicht vorhanden</span><?php endif; ?></td>
						<td><strong><?php echo esc_html( self::translation_status_label( $translation ) ); ?></strong><?php if ( $english_status ) : ?><br><?php echo esc_html( self::post_status_label( $english_status ) ); ?><?php endif; ?></td>
						<td><?php if ( $english_id ) : ?><a class="button button-small" href="<?php echo esc_url( get_edit_post_link( $english_id ) ); ?>">EN bearbeiten</a><?php elseif ( Leadwerk_Translation_API::is_active( 'en' ) ) : ?><a class="button button-small" href="<?php echo esc_url( $clone_url ); ?>">EN-Entwurf erstellen</a><?php else : ?>Englisch deaktiviert<?php endif; ?></td>
					</tr>
				<?php endforeach; ?>
				</tbody>
			</table>
		</div>
		<?php
	}

	/** Show page language and translation actions in the WordPress admin bar. */
	public static function admin_bar( $wp_admin_bar ) {
		if ( ! is_user_logged_in() || ! current_user_can( 'edit_pages' ) || ! Leadwerk_Translation_API::is_active( 'en' ) ) {
			return;
		}

		$pages      = self::source_pages();
		$translated = 0;
		foreach ( $pages as $page ) {
			if ( Leadwerk_Translation_API::get_counterpart( $page->ID, 'en' ) ) {
				$translated++;
			}
		}

		$post_id = 0;
		if ( is_admin() ) {
			// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only screen context.
			$post_id = isset( $_GET['post'] ) ? absint( $_GET['post'] ) : 0;
		} elseif ( is_page() ) {
			$post_id = get_queried_object_id();
		}
		if ( $post_id && 'page' !== get_post_type( $post_id ) ) {
			$post_id = 0;
		}

		$language = $post_id ? Leadwerk_Translation_API::language_of( $post_id ) : '';
		$title    = $post_id ? 'Sprache: ' . strtoupper( $language ) : sprintf( 'Übersetzungen: %d/%d EN', $translated, count( $pages ) );
		$wp_admin_bar->add_node(
			array(
				'id'    => 'leadwerk-language',
				'title' => '<span class="ab-icon dashicons-translation" aria-hidden="true"></span><span class="ab-label">' . esc_html( $title ) . '</span>',
				'href'  => admin_url( 'admin.php?page=leadwerk-translations' ),
				'meta'  => array( 'title' => 'Leadwerk Translation Dashboard' ),
			)
		);
		$wp_admin_bar->add_node( array( 'parent' => 'leadwerk-language', 'id' => 'leadwerk-language-dashboard', 'title' => 'Translation Dashboard', 'href' => admin_url( 'admin.php?page=leadwerk-translations' ) ) );
		if ( ! $post_id ) {
			return;
		}

		$other_language = 'en' === $language ? 'de' : 'en';
		$counterpart    = Leadwerk_Translation_API::get_counterpart( $post_id, $other_language );
		if ( $counterpart ) {
			$wp_admin_bar->add_node( array( 'parent' => 'leadwerk-language', 'id' => 'leadwerk-language-counterpart', 'title' => strtoupper( $other_language ) . ' bearbeiten', 'href' => get_edit_post_link( $counterpart ) ) );
		} elseif ( 'de' === $language && current_user_can( 'edit_post', $post_id ) ) {
			$url = wp_nonce_url( admin_url( 'admin-post.php?action=leadwerk_clone_english&post_id=' . $post_id ), 'leadwerk_clone_english_' . $post_id );
			$wp_admin_bar->add_node( array( 'parent' => 'leadwerk-language', 'id' => 'leadwerk-language-clone', 'title' => 'EN-Entwurf erstellen', 'href' => $url ) );
		}
	}

	public static function save_settings() {
		if ( empty( $_POST['leadwerk_languages_submit'] ) || ! current_user_can( 'manage_options' ) ) {
			return;
		}
		$nonce = isset( $_POST['leadwerk_languages_nonce'] ) ? sanitize_text_field( wp_unslash( $_POST['leadwerk_languages_nonce'] ) ) : '';
		if ( ! wp_verify_nonce( $nonce, 'leadwerk_languages_save' ) ) {
			wp_die( esc_html__( 'Ungültige Anfrage.', 'leadwerk-wpml-clone' ), '', array( 'response' => 403 ) );
		}
		$languages = array( 'de' );
		if ( ! empty( $_POST['leadwerk_enable_en'] ) ) {
			$languages[] = 'en';
		}
		update_option( 'leadwerk_translation_languages', $languages, false );
		update_option( 'leadwerk_translation_default', 'de', false );
		flush_rewrite_rules( false );
		wp_safe_redirect( admin_url( 'admin.php?page=leadwerk-languages&updated=1' ) );
		exit;
	}

	public static function metabox( $post ) {
		if ( ! $post instanceof WP_Post ) {
			return;
		}
		add_meta_box(
			'leadwerk-translation',
			'Leadwerk Übersetzung',
			array( __CLASS__, 'render_metabox' ),
			'page',
			'side',
			'high'
		);
	}

	public static function render_metabox( $post ) {
		$language    = Leadwerk_Translation_API::language_of( $post->ID );
		$status      = sanitize_key( (string) get_post_meta( $post->ID, '_leadwerk_translation_status', true ) );
		$counterpart = Leadwerk_Translation_API::get_counterpart( $post->ID, 'de' === $language ? 'en' : 'de' );
		echo '<p><strong>Sprache:</strong> ' . esc_html( strtoupper( $language ) ) . '</p>';
		echo '<p><strong>Status:</strong> ' . esc_html( $status ? $status : ( 'de' === $language ? 'Original' : 'not_translated' ) ) . '</p>';
		if ( $counterpart ) {
			echo '<p><a href="' . esc_url( get_edit_post_link( $counterpart ) ) . '">Gegenstück bearbeiten</a></p>';
		} elseif ( 'de' === $language && Leadwerk_Translation_API::is_active( 'en' ) ) {
			$url = wp_nonce_url(
				admin_url( 'admin-post.php?action=leadwerk_clone_english&post_id=' . $post->ID ),
				'leadwerk_clone_english_' . $post->ID
			);
			echo '<p><a class="button" href="' . esc_url( $url ) . '">EN-Entwurf klonen</a></p>';
		} elseif ( 'de' === $language ) {
			echo '<p class="description">Englisch ist deaktiviert. Es gibt keine /en/-Route oder Sprachumschaltung.</p>';
		}
	}

	public static function clone_action() {
		$post_id = absint( $_GET['post_id'] ?? 0 );
		if ( ! $post_id || ! current_user_can( 'edit_post', $post_id ) ) {
			wp_die( esc_html__( 'Keine Berechtigung.', 'leadwerk-wpml-clone' ), '', array( 'response' => 403 ) );
		}
		check_admin_referer( 'leadwerk_clone_english_' . $post_id );
		self::$syncing = true;
		$result        = Leadwerk_Translation_API::clone_to_english( $post_id );
		self::$syncing = false;
		if ( is_wp_error( $result ) ) {
			wp_die( esc_html( $result->get_error_message() ), '', array( 'response' => 400 ) );
		}
		wp_safe_redirect( get_edit_post_link( $result, 'url' ) );
		exit;
	}

	/** Create drafts for all source pages that do not yet have an EN pair. */
	public static function clone_all_action() {
		if ( ! current_user_can( 'manage_options' ) || ! Leadwerk_Translation_API::is_active( 'en' ) ) {
			wp_die( esc_html__( 'Keine Berechtigung.', 'leadwerk-wpml-clone' ), '', array( 'response' => 403 ) );
		}
		check_admin_referer( 'leadwerk_clone_all_english' );
		$created       = 0;
		$failed        = 0;
		self::$syncing = true;
		foreach ( self::source_pages() as $page ) {
			if ( Leadwerk_Translation_API::get_counterpart( $page->ID, 'en' ) ) {
				continue;
			}
			$result = Leadwerk_Translation_API::clone_to_english( $page->ID );
			if ( is_wp_error( $result ) ) {
				$failed++;
			} else {
				$created++;
			}
		}
		self::$syncing = false;
		wp_safe_redirect( add_query_arg( array( 'page' => 'leadwerk-translations', 'created' => $created, 'failed' => $failed ), admin_url( 'admin.php' ) ) );
		exit;
	}

	public static function mark_counterpart_for_review( $post_id, $post, $update ) {
		if ( self::$syncing || ! $update || ! $post instanceof WP_Post || 'de' !== Leadwerk_Translation_API::language_of( $post_id ) ) {
			return;
		}
		if ( wp_is_post_autosave( $post_id ) || wp_is_post_revision( $post_id ) ) {
			return;
		}
		$english_id = Leadwerk_Translation_API::get_counterpart( $post_id, 'en' );
		if ( $english_id ) {
			update_post_meta( $english_id, '_leadwerk_translation_status', 'needs_review' );
		}
	}

	public static function switcher_shortcode() {
		if ( ! Leadwerk_Translation_API::is_active( 'en' ) || ! is_singular( 'page' ) ) {
			return '';
		}
		$post_id        = get_queried_object_id();
		$other_language = 'en' === Leadwerk_Translation_API::language_of( $post_id ) ? 'de' : 'en';
		$other_id       = Leadwerk_Translation_API::get_counterpart( $post_id, $other_language );
		if ( ! $other_id || 'publish' !== get_post_status( $other_id ) ) {
			return '';
		}
		return '<a class="leadwerk-language-switcher" href="' . esc_url( get_permalink( $other_id ) ) . '" hreflang="' . esc_attr( $other_language ) . '">' . esc_html( strtoupper( $other_language ) ) . '</a>';
	}

	/** Return all German source pages, including legacy pages without language meta. */
	private static function source_pages() {
		static $pages = null;
		if ( null !== $pages ) {
			return $pages;
		}
		$all = get_posts(
			array(
				'post_type'      => 'page',
				'post_status'    => array( 'publish', 'draft', 'private', 'pending', 'future' ),
				'posts_per_page' => -1,
				'orderby'        => array( 'menu_order' => 'ASC', 'title' => 'ASC' ),
				'order'          => 'ASC',
			)
		);
		$pages = array_values(
			array_filter(
				$all,
				static function ( $page ) {
					return $page instanceof WP_Post && 'de' === Leadwerk_Translation_API::language_of( $page->ID );
				}
			)
		);
		return $pages;
	}

	private static function post_status_label( $status ) {
		$object = get_post_status_object( $status );
		return $object && isset( $object->label ) ? $object->label : ucfirst( (string) $status );
	}

	private static function translation_status_label( $status ) {
		$labels = array(
			'missing'        => 'Fehlt',
			'not_translated' => 'Nicht übersetzt',
			'needs_review'   => 'Prüfung nötig',
			'translated'     => 'Übersetzt',
		);
		return isset( $labels[ $status ] ) ? $labels[ $status ] : ucwords( str_replace( '_', ' ', $status ) );
	}
}
