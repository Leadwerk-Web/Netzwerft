# Leadwerk T2med Theme Suite

Version 3.0.2 includes the former Leadwerk plugins directly as theme modules:

- Leadwerk Fields 2.0.2
- Leadwerk Importer 3.1.5
- Leadwerk WPML Clone 4.0.0
- Leadwerk Migration 1.5.11

All existing post meta, options, Site Family identity, backup manifests and sync
state keep their original keys. No content or settings migration is required.

## Admin navigation

The modules are available below **Leadwerk Optionen**:

- Leadwerk Optionen (global fields)
- T2med Import
- Übersetzungen (translation dashboard)
- Sprachen
- Migration: Overview
- Migration: Export
- Migration: Import
- Migration: Backups
- Migration: Automation
- Migration: Site Sync

When English is enabled, logged-in editors also see `Sprache: DE/EN` in the
WordPress admin bar. It links to the counterpart editor or offers creation of a
missing EN draft. The translation dashboard shows every page pair and review
state; it can create all missing EN drafts in one nonce-protected action.

WPML Clone 4.0 adds the ACM-grade segment workflow in a T2med-specific form:
structured field and HTML-segment editing, exact-match translation memory,
source-change review flags without overwriting EN text, localized global
header/footer option strings, list-table language filters, published-pair-only
routes, switcher links, canonicals, hreflang and sitemap integration. Media and
attachments remain shared; page-reference fields map to a published EN pair or
fall back safely to DE.

## Upgrade from separate plugins

1. Install and activate this theme.
2. Deactivate `leadwerk-fields`, `leadwerk_importer`, `leadwerk-wpml-clone` and
   `leadwerk-migration` together.
3. Confirm that the module versions appear under Leadwerk Optionen.
4. Delete the four inactive plugin directories.

Do not deactivate WPForms; it remains an external dependency of the T2med form.

## Migration release updates

The embedded Migration core remains publisher-signed. Hub can continue using
its signed release channel. A newer verified release is staged, verified again,
atomically promoted into the active theme and removed from the temporary plugin
location, so WordPress does not retain a separate Migration plugin.
