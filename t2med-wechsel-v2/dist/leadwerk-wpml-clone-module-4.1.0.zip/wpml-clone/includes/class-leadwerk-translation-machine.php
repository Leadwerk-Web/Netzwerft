<?php
/** Optional, rate-limited DeepL API integration for the segment editor. */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class Leadwerk_Translation_Machine {
	const OPTION_KEY  = 'leadwerk_translation_deepl_key';
	const OPTION_TIER = 'leadwerk_translation_deepl_tier';

	public static function init() {
		add_action( 'wp_ajax_leadwerk_translate_segment', array( __CLASS__, 'ajax_translate' ) );
	}

	public static function is_configured() {
		return '' !== self::auth_key();
	}

	public static function tier() {
		return 'pro' === get_option( self::OPTION_TIER, 'free' ) ? 'pro' : 'free';
	}

	public static function save_settings( $new_key, $tier, $clear = false ) {
		update_option( self::OPTION_TIER, 'pro' === sanitize_key( (string) $tier ) ? 'pro' : 'free', false );
		if ( $clear ) {
			delete_option( self::OPTION_KEY );
			return true;
		}
		$new_key = trim( (string) $new_key );
		if ( '' === $new_key ) {
			return true;
		}
		$encrypted = self::encrypt( $new_key );
		return $encrypted ? update_option( self::OPTION_KEY, $encrypted, false ) : false;
	}

	public static function ajax_translate() {
		if ( ! current_user_can( 'edit_pages' ) ) {
			wp_send_json_error( array( 'message' => 'Keine Berechtigung.' ), 403 );
		}
		check_ajax_referer( 'leadwerk_machine_translate', 'nonce' );
		$user_id = get_current_user_id();
		$key     = 'leadwerk_deepl_rate_' . $user_id;
		$count   = absint( get_transient( $key ) );
		if ( $count >= 240 ) {
			wp_send_json_error( array( 'message' => 'Übersetzungslimit erreicht. Bitte eine Minute warten.' ), 429 );
		}
		set_transient( $key, $count + 1, MINUTE_IN_SECONDS );

		$auth_key = self::auth_key();
		if ( '' === $auth_key ) {
			wp_send_json_error( array( 'message' => 'DeepL API-Schlüssel ist nicht eingerichtet.' ), 400 );
		}
		$text = isset( $_POST['text'] ) ? trim( (string) wp_unslash( $_POST['text'] ) ) : '';
		$type = isset( $_POST['type'] ) ? sanitize_key( wp_unslash( $_POST['type'] ) ) : 'text';
		if ( '' === $text || strlen( $text ) > 10000 ) {
			wp_send_json_error( array( 'message' => 'Segment ist leer oder zu lang.' ), 400 );
		}
		$endpoint = 'pro' === self::tier() ? 'https://api.deepl.com/v2/translate' : 'https://api-free.deepl.com/v2/translate';
		$body     = array( 'text' => $text, 'source_lang' => 'DE', 'target_lang' => 'EN-US', 'preserve_formatting' => '1' );
		if ( 'richtext' === $type ) {
			$body['tag_handling'] = 'html';
		}
		$response = wp_safe_remote_post(
			$endpoint,
			array(
				'timeout' => 25,
				'headers' => array( 'Authorization' => 'DeepL-Auth-Key ' . $auth_key ),
				'body'    => $body,
			)
		);
		if ( is_wp_error( $response ) ) {
			wp_send_json_error( array( 'message' => 'DeepL bağlantısı kurulamadı.' ), 502 );
		}
		$code = wp_remote_retrieve_response_code( $response );
		$data = json_decode( (string) wp_remote_retrieve_body( $response ), true );
		if ( 200 !== $code || empty( $data['translations'][0]['text'] ) ) {
			$message = 403 === $code ? 'DeepL API anahtarı reddedildi.' : ( 456 === $code ? 'DeepL kotası doldu.' : 'DeepL çevirisi başarısız oldu.' );
			wp_send_json_error( array( 'message' => $message ), $code >= 400 && $code < 600 ? $code : 502 );
		}
		$translation = 'richtext' === $type ? wp_kses_post( $data['translations'][0]['text'] ) : sanitize_textarea_field( $data['translations'][0]['text'] );
		wp_send_json_success( array( 'translation' => $translation ) );
	}

	private static function auth_key() {
		if ( defined( 'LEADWERK_DEEPL_AUTH_KEY' ) && is_string( LEADWERK_DEEPL_AUTH_KEY ) ) {
			return trim( LEADWERK_DEEPL_AUTH_KEY );
		}
		$stored = get_option( self::OPTION_KEY, '' );
		return is_string( $stored ) ? self::decrypt( $stored ) : '';
	}

	private static function encryption_key() {
		return hash( 'sha256', wp_salt( 'auth' ) . '|leadwerk-translation-machine-v1', true );
	}

	private static function encrypt( $plain ) {
		$key = self::encryption_key();
		if ( function_exists( 'sodium_crypto_secretbox' ) ) {
			$nonce = random_bytes( SODIUM_CRYPTO_SECRETBOX_NONCEBYTES );
			return 'sodium:' . base64_encode( $nonce . sodium_crypto_secretbox( $plain, $nonce, $key ) );
		}
		if ( function_exists( 'openssl_encrypt' ) ) {
			$iv  = random_bytes( 12 );
			$tag = '';
			$out = openssl_encrypt( $plain, 'aes-256-gcm', $key, OPENSSL_RAW_DATA, $iv, $tag );
			return false !== $out ? 'openssl:' . base64_encode( $iv . $tag . $out ) : '';
		}
		return '';
	}

	private static function decrypt( $stored ) {
		if ( 0 === strpos( $stored, 'sodium:' ) && function_exists( 'sodium_crypto_secretbox_open' ) ) {
			$raw = base64_decode( substr( $stored, 7 ), true );
			if ( ! is_string( $raw ) || strlen( $raw ) <= SODIUM_CRYPTO_SECRETBOX_NONCEBYTES ) {
				return '';
			}
			$nonce = substr( $raw, 0, SODIUM_CRYPTO_SECRETBOX_NONCEBYTES );
			$out   = sodium_crypto_secretbox_open( substr( $raw, SODIUM_CRYPTO_SECRETBOX_NONCEBYTES ), $nonce, self::encryption_key() );
			return is_string( $out ) ? $out : '';
		}
		if ( 0 === strpos( $stored, 'openssl:' ) && function_exists( 'openssl_decrypt' ) ) {
			$raw = base64_decode( substr( $stored, 8 ), true );
			if ( ! is_string( $raw ) || strlen( $raw ) <= 28 ) {
				return '';
			}
			$out = openssl_decrypt( substr( $raw, 28 ), 'aes-256-gcm', self::encryption_key(), OPENSSL_RAW_DATA, substr( $raw, 0, 12 ), substr( $raw, 12, 16 ) );
			return is_string( $out ) ? $out : '';
		}
		return '';
	}
}
