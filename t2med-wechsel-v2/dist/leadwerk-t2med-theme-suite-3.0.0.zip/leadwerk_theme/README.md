# Leadwerk T2med Theme Suite

Version 3.0.0 includes the former Leadwerk plugins directly as theme modules:

- Leadwerk Fields 2.0.2
- Leadwerk Importer 3.1.5
- Leadwerk WPML Clone 3.0.0
- Leadwerk Migration 1.5.11

All existing post meta, options, Site Family identity, backup manifests and sync
state keep their original keys. No content or settings migration is required.

## Admin navigation

The modules are available below **Leadwerk Optionen**:

- Leadwerk Optionen (global fields)
- T2med Import
- Sprachen & Klone
- Migration: Overview
- Migration: Export
- Migration: Import
- Migration: Backups
- Migration: Automation
- Migration: Site Sync

## Upgrade from separate plugins

1. Install and activate this theme.
2. Deactivate `leadwerk-fields`, `leadwerk_importer`, `leadwerk-wpml-clone` and
   `leadwerk-migration` together.
3. Confirm that the module versions appear under Leadwerk Optionen.
4. Delete the four inactive plugin directories.

Do not deactivate WPForms; it remains an external dependency of the T2med form.

## Migration release updates

The embedded Migration core remains publisher-signed. Hub can continue using
its signed release channel. A newer verified release is staged, verified again,
atomically promoted into the active theme and removed from the temporary plugin
location, so WordPress does not retain a separate Migration plugin.

