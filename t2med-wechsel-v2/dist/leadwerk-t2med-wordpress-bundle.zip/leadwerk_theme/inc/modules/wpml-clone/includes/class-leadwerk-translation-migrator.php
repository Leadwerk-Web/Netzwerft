<?php
/** Upgrade and compatibility migration for earlier Leadwerk/ACM metadata. */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class Leadwerk_Translation_Migrator {
	const VERSION = '4.3.3';
	const OPTION  = 'leadwerk_translation_db_version';

	public static function maybe_upgrade() {
		$installed = (string) get_option( self::OPTION, '' );
		self::ensure_defaults();
		if ( self::VERSION === $installed ) {
			return;
		}
		if ( '' === $installed || version_compare( $installed, '4.3.2', '<' ) ) {
			update_option( 'leadwerk_translation_auto_switcher', true, false );
		}
		self::migrate_page_identities();
		update_option( self::OPTION, self::VERSION, false );
		update_option( 'leadwerk_wpml_clone_version', self::VERSION, false );
	}

	private static function ensure_defaults() {
		if ( false === get_option( Leadwerk_Translation_API::OPTION_LANGUAGES, false ) ) {
			update_option( Leadwerk_Translation_API::OPTION_LANGUAGES, array( 'de' ), false );
		}
		update_option( Leadwerk_Translation_API::OPTION_DEFAULT, 'de', false );
		if ( null === get_option( 'leadwerk_translation_auto_switcher', null ) ) {
			update_option( 'leadwerk_translation_auto_switcher', true, false );
		}
		if ( false === get_option( 'leadwerk_translation_switcher_style', false ) ) {
			update_option( 'leadwerk_translation_switcher_style', 'compact', false );
		}
		if ( class_exists( 'Leadwerk_Shared_Translations' ) ) {
			$stored   = get_option( 'leadwerk_translation_runtime_strings_en', array() );
			$stored   = is_array( $stored ) ? $stored : array();
			$defaults = array();
			foreach ( Leadwerk_Shared_Translations::definitions() as $key => $definition ) {
				$defaults[ $key ] = (string) $definition['default'];
			}
			$merged = array_merge( $defaults, $stored );
			if ( $merged !== $stored ) {
				update_option( 'leadwerk_translation_runtime_strings_en', $merged, false );
			}
		}
	}

	private static function migrate_page_identities() {
		$ids = get_posts( array( 'post_type' => 'page', 'post_status' => array( 'publish', 'draft', 'private', 'pending', 'future' ), 'posts_per_page' => -1, 'fields' => 'ids' ) );
		foreach ( $ids as $post_id ) {
			$language = sanitize_key( (string) get_post_meta( $post_id, Leadwerk_Translation_API::META_LANG, true ) );
			if ( ! $language ) {
				$language = sanitize_key( (string) get_post_meta( $post_id, 'leadwerk_lang', true ) );
			}
			$language = in_array( $language, array( 'de', 'en' ), true ) ? $language : 'de';
			$group    = sanitize_key( (string) get_post_meta( $post_id, Leadwerk_Translation_API::META_GROUP, true ) );
			if ( ! $group ) {
				$group = sanitize_key( (string) get_post_meta( $post_id, 'leadwerk_trid', true ) );
			}
			if ( $group ) {
				update_post_meta( $post_id, Leadwerk_Translation_API::META_GROUP, $group );
			}
			Leadwerk_Translation_API::ensure_identity( $post_id, $language );
			$legacy_status = sanitize_key( (string) get_post_meta( $post_id, 'leadwerk_translation_status', true ) );
			if ( 'en' === $language && $legacy_status && ! get_post_meta( $post_id, Leadwerk_Translation_API::META_STATUS, true ) ) {
				$map = array( 'complete' => 'translated', 'needs_update' => 'needs_review', 'in_progress' => 'in_progress', 'not_translated' => 'not_translated' );
				Leadwerk_Translation_API::update_status( $post_id, $map[ $legacy_status ] ?? 'not_translated' );
			}
		}
	}
}
