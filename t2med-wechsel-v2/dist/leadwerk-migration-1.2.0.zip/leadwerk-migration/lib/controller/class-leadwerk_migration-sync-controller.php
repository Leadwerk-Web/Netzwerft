<?php
/**
 * Leadwerk Site Sync administration.
 *
 * Copyright (C) 2026 Leadwerk.
 * Licensed under GPLv3 or later.
 */

if ( ! defined( 'ABSPATH' ) ) {
	die( 'Direct access is not allowed.' );
}

class Leadwerk_Migration_Sync_Controller {

	const NOTICE_PREFIX = 'leadwerk_migration_sync_notice_';

	public static function index() {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( esc_html__( 'You are not allowed to manage Site Sync.', 'leadwerk-migration' ) );
		}

		$bootstrap = Leadwerk_Migration_Sync::bootstrap_registration();
		$family      = get_option( LEADWERK_MIGRATION_SYNC_FAMILY, array() );
		$family      = is_array( $family ) ? $family : array();
		$environment = Leadwerk_Migration_Site_Identity::ensure_environment();
		$settings    = Leadwerk_Migration_Site_Identity::settings();
		$directory   = array();
		$jobs        = array();
		$remote_error = is_wp_error( $bootstrap ) ? $bootstrap->get_error_message() : '';

		if ( '' === $remote_error && Leadwerk_Migration_Site_Identity::valid_id( isset( $family['family_id'] ) ? $family['family_id'] : '' ) && 'unregistered' !== $environment['registration'] ) {
			$directory_result = Leadwerk_Migration_Sync::directory();
			if ( is_wp_error( $directory_result ) ) {
				$remote_error = $directory_result->get_error_message();
			} else {
				$directory = $directory_result;
				$jobs_result = Leadwerk_Migration_Sync::jobs();
				if ( is_wp_error( $jobs_result ) ) {
					$remote_error = $jobs_result->get_error_message();
				} else {
					$jobs = $jobs_result;
				}
			}
		}

		Leadwerk_Migration_Template::render(
			'sync/index',
			array(
				'family'       => $family,
				'environment'  => $environment,
				'settings'     => $settings,
				'directory'    => $directory,
				'jobs'         => $jobs,
				'remote_error' => $remote_error,
				'notice'       => self::consume_notice(),
				'hub_data'     => Leadwerk_Migration_Sync_Hub::enabled() ? Leadwerk_Migration_Sync_Hub::admin_data() : array( 'families' => array(), 'environments' => array(), 'jobs' => array() ),
			)
		);
	}

	public static function enqueue_assets( $hook ) {
		if ( 'leadwerk-migration_page_leadwerk_migration_sync' !== $hook ) {
			return;
		}
		wp_enqueue_style( 'leadwerk-migration-dashboard', Leadwerk_Migration_Template::asset_link( 'css/leadwerk-dashboard.css' ), array(), LEADWERK_MIGRATION_VERSION );
		wp_enqueue_style( 'leadwerk-migration-sync', Leadwerk_Migration_Template::asset_link( 'css/leadwerk-sync.css' ), array( 'leadwerk-migration-dashboard' ), LEADWERK_MIGRATION_VERSION );
		wp_enqueue_script( 'leadwerk-migration-sync', Leadwerk_Migration_Template::asset_link( 'javascript/leadwerk-sync.js' ), array(), LEADWERK_MIGRATION_VERSION, true );
	}

	public static function save_settings() {
		self::require_action( 'leadwerk_migration_sync_save' );
		$raw = isset( $_POST['settings'] ) && is_array( $_POST['settings'] ) ? wp_unslash( $_POST['settings'] ) : array();
		$current = Leadwerk_Migration_Site_Identity::settings();
		$settings = Leadwerk_Migration_Site_Identity::sanitize_settings( $raw );

		if ( empty( $current['hub_mode'] ) && ! empty( $settings['hub_mode'] ) ) {
			$confirmation = isset( $_POST['hub_confirmation'] ) ? trim( sanitize_text_field( wp_unslash( $_POST['hub_confirmation'] ) ) ) : '';
			if ( ! hash_equals( 'ENABLE HUB', $confirmation ) ) {
				self::finish( new WP_Error( 'leadwerk_sync_hub_confirmation', __( 'Hub mode was not enabled. Enter ENABLE HUB exactly to confirm the central registry role.', 'leadwerk-migration' ) ) );
			}
		}

		update_option( LEADWERK_MIGRATION_SYNC_SETTINGS, $settings, false );
		Leadwerk_Migration_Site_Identity::ensure_environment();
		Leadwerk_Migration_Sync_Hub::maybe_install();

		$family = get_option( LEADWERK_MIGRATION_SYNC_FAMILY, array() );
		$project_name = isset( $_POST['project_name'] ) ? sanitize_text_field( wp_unslash( $_POST['project_name'] ) ) : '';
		if ( is_array( $family ) && Leadwerk_Migration_Site_Identity::valid_id( isset( $family['family_id'] ) ? $family['family_id'] : '' ) && $project_name !== '' ) {
			Leadwerk_Migration_Site_Identity::ensure_family( $project_name );
		}
		self::finish( true, __( 'Site Sync settings saved.', 'leadwerk-migration' ) );
	}

	/** Legacy action: identity creation and Hub enrollment no longer need a backup. */
	public static function initialize() {
		self::require_action( 'leadwerk_migration_sync_initialize' );
		$existing = get_option( LEADWERK_MIGRATION_SYNC_FAMILY, array() );
		$had_family = is_array( $existing ) && Leadwerk_Migration_Site_Identity::valid_id( isset( $existing['family_id'] ) ? $existing['family_id'] : '' );
		$project_name = isset( $_POST['project_name'] ) ? sanitize_text_field( wp_unslash( $_POST['project_name'] ) ) : '';
		Leadwerk_Migration_Site_Identity::ensure_family( $project_name );
		$result = Leadwerk_Migration_Sync::bootstrap_registration();
		if ( is_wp_error( $result ) && ! $had_family ) {
			// Keep the identity: the cron worker will retry enrollment automatically.
			self::finish( true, __( 'Site Family identity was created. Hub is currently unreachable, so automatic enrollment will retry on the next heartbeat.', 'leadwerk-migration' ) );
		}
		self::finish( $result, __( 'Site Family identity was created and automatically enrolled with Hub. No backup was required.', 'leadwerk-migration' ) );
	}

	public static function register() {
		self::require_action( 'leadwerk_migration_sync_register' );
		self::finish( Leadwerk_Migration_Sync::bootstrap_registration(), __( 'Automatic Hub enrollment refreshed.', 'leadwerk-migration' ) );
	}

	public static function promote_live() {
		self::require_action( 'leadwerk_migration_sync_promote_live' );
		$environment = Leadwerk_Migration_Site_Identity::ensure_environment();
		if ( isset( $environment['type'] ) && 'live' === $environment['type'] ) {
			self::finish( true, __( 'This environment is already marked as live.', 'leadwerk-migration' ) );
		}
		$confirmation = isset( $_POST['promotion_confirmation'] ) ? trim( sanitize_text_field( wp_unslash( $_POST['promotion_confirmation'] ) ) ) : '';
		if ( ! hash_equals( 'PROMOTE LIVE', $confirmation ) ) {
			self::finish( new WP_Error( 'leadwerk_sync_promotion_confirmation', __( 'Promotion was not completed. Enter PROMOTE LIVE exactly.', 'leadwerk-migration' ) ) );
		}
		Leadwerk_Migration_Site_Identity::promote_to_live();
		// Best effort: an offline Hub will receive the new URL/type on the next
		// scheduled heartbeat without rolling back the local promotion.
		Leadwerk_Migration_Sync::heartbeat();
		self::finish( true, __( 'The existing staging environment was promoted to live without changing its environment identity. The Hub will reflect it on the next heartbeat.', 'leadwerk-migration' ) );
	}

	public static function request_sync() {
		self::require_action( 'leadwerk_migration_sync_request' );
		$source_id = isset( $_POST['source_environment_id'] ) ? strtolower( sanitize_text_field( wp_unslash( $_POST['source_environment_id'] ) ) ) : '';
		$target_id = isset( $_POST['target_environment_id'] ) ? strtolower( sanitize_text_field( wp_unslash( $_POST['target_environment_id'] ) ) ) : '';
		if ( ! Leadwerk_Migration_Site_Identity::valid_id( $source_id ) || ! Leadwerk_Migration_Site_Identity::valid_id( $target_id ) ) {
			self::finish( new WP_Error( 'leadwerk_sync_invalid_selection', __( 'Choose a valid source and target environment.', 'leadwerk-migration' ) ) );
		}

		$result = Leadwerk_Migration_Sync::request_sync( $source_id, $target_id );
		self::finish( $result, __( 'Version and online checks passed. Full-site synchronization started without registration or approval steps.', 'leadwerk-migration' ) );
	}

	/** Retained for old admin links; version 1.2 jobs never require this step. */
	public static function approve_sync() {
		self::require_action( 'leadwerk_migration_sync_approve' );
		self::finish( true, __( 'Site Sync registration and transfer approvals are automatic in Leadwerk Migration 1.2.', 'leadwerk-migration' ) );
	}

	public static function process_now() {
		self::require_action( 'leadwerk_migration_sync_process' );
		self::finish( Leadwerk_Migration_Sync::process(), __( 'The Site Sync worker completed its current batch.', 'leadwerk-migration' ) );
	}

	public static function hub_approve() {
		self::hub_status( 'approved', 'leadwerk_migration_hub_approve' );
	}

	public static function hub_revoke() {
		self::hub_status( 'revoked', 'leadwerk_migration_hub_revoke' );
	}

	private static function hub_status( $status, $nonce_action ) {
		self::require_action( $nonce_action );
		$kind = isset( $_POST['kind'] ) ? sanitize_key( wp_unslash( $_POST['kind'] ) ) : '';
		$id = isset( $_POST['registry_id'] ) ? strtolower( sanitize_text_field( wp_unslash( $_POST['registry_id'] ) ) ) : '';
		$result = Leadwerk_Migration_Sync_Hub::set_registry_status( $kind, $id, $status );
		self::finish( $result ? true : new WP_Error( 'leadwerk_hub_status_failed', __( 'The Hub registry status could not be changed.', 'leadwerk-migration' ) ), __( 'Hub registry status updated.', 'leadwerk-migration' ) );
	}

	private static function find_environment( $directory, $id ) {
		foreach ( is_array( $directory ) ? $directory : array() as $environment ) {
			if ( is_array( $environment ) && isset( $environment['environment_id'] ) && hash_equals( (string) $environment['environment_id'], (string) $id ) ) {
				return $environment;
			}
		}
		return null;
	}

	private static function require_action( $nonce_action ) {
		$nonce = isset( $_REQUEST['_wpnonce'] ) ? sanitize_text_field( wp_unslash( $_REQUEST['_wpnonce'] ) ) : '';
		if ( ! Leadwerk_Migration_Security::authorize_admin_action( 'manage_options', $nonce_action, $nonce ) ) {
			wp_die( esc_html__( 'Security check failed.', 'leadwerk-migration' ), '', array( 'response' => 403 ) );
		}
	}

	private static function finish( $result, $success_message = '' ) {
		if ( is_wp_error( $result ) || false === $result ) {
			$message = is_wp_error( $result ) ? $result->get_error_message() : __( 'The Site Sync action failed.', 'leadwerk-migration' );
			self::store_notice( 'error', $message );
		} else {
			self::store_notice( 'success', $success_message !== '' ? $success_message : __( 'Site Sync action completed.', 'leadwerk-migration' ) );
		}
		wp_safe_redirect( add_query_arg( 'page', 'leadwerk_migration_sync', admin_url( 'admin.php' ) ) );
		exit;
	}

	private static function store_notice( $type, $message ) {
		set_transient(
			self::NOTICE_PREFIX . get_current_user_id(),
			array( 'type' => 'success' === $type ? 'success' : 'error', 'message' => substr( wp_strip_all_tags( (string) $message ), 0, 2000 ) ),
			MINUTE_IN_SECONDS * 5
		);
	}

	private static function consume_notice() {
		$key = self::NOTICE_PREFIX . get_current_user_id();
		$notice = get_transient( $key );
		delete_transient( $key );
		return is_array( $notice ) ? $notice : array();
	}
}
