<?php
/** Standalone smoke checks for Site Sync detection and fail-closed preflight. */

define( 'ABSPATH', __DIR__ . '/' );
define( 'MINUTE_IN_SECONDS', 60 );
define( 'LEADWERK_MIGRATION_VERSION', '1.2.0' );

class WP_Error {
	private $code;
	private $message;
	public function __construct( $code, $message ) { $this->code = $code; $this->message = $message; }
	public function get_error_code() { return $this->code; }
	public function get_error_message() { return $this->message; }
}

function is_wp_error( $value ) { return $value instanceof WP_Error; }
function __( $message ) { return $message; }
function sanitize_key( $value ) { return strtolower( preg_replace( '/[^a-z0-9_\-]/', '', (string) $value ) ); }
function wp_parse_url( $url, $component = -1 ) { return parse_url( $url, $component ); }

function leadwerk_sync_assert( $condition, $message ) {
	if ( ! $condition ) {
		fwrite( STDERR, "FAIL: {$message}\n" );
		exit( 1 );
	}
}

require_once dirname( __DIR__ ) . '/lib/model/class-leadwerk_migration-site-identity.php';
require_once dirname( __DIR__ ) . '/lib/model/class-leadwerk_migration-sync-hub.php';
require_once dirname( __DIR__ ) . '/lib/model/class-leadwerk_migration-sync.php';

leadwerk_sync_assert( Leadwerk_Migration_Site_Identity::environment_type( 'http://netzwerft.local' ) === 'local', 'a .local host must be local' );
leadwerk_sync_assert( Leadwerk_Migration_Site_Identity::environment_type( 'https://b9yyrjh.myrdbx.io' ) === 'staging', 'myrdbx.io must be staging' );
leadwerk_sync_assert( Leadwerk_Migration_Site_Identity::environment_type( 'https://example.com' ) === 'live', 'a public host must default to live' );

$fresh = array( 'last_seen_at' => gmdate( 'Y-m-d H:i:s', time() - 899 ) );
$stale = array( 'last_seen_at' => gmdate( 'Y-m-d H:i:s', time() - 901 ) );
leadwerk_sync_assert( Leadwerk_Migration_Sync_Hub::environment_is_online( $fresh ), 'a recent heartbeat must be online' );
leadwerk_sync_assert( ! Leadwerk_Migration_Sync_Hub::environment_is_online( $stale ), 'a heartbeat older than 15 minutes must be offline' );

$source = array( 'wordpress_version' => '7.0.4', 'php_version' => '8.3.30', 'plugin_version' => LEADWERK_MIGRATION_VERSION );
$target = $source;
leadwerk_sync_assert( Leadwerk_Migration_Sync::version_preflight( $source, $target ) === true, 'equal versions must pass' );
$target['wordpress_version'] = '7.0.3';
$error = Leadwerk_Migration_Sync::version_preflight( $source, $target );
leadwerk_sync_assert( is_wp_error( $error ) && $error->get_error_code() === 'leadwerk_sync_wordpress_version_mismatch', 'WordPress mismatch must be the first failed gate' );
$target = $source;
$target['php_version'] = '8.2.0';
$error = Leadwerk_Migration_Sync::version_preflight( $source, $target );
leadwerk_sync_assert( is_wp_error( $error ) && $error->get_error_code() === 'leadwerk_sync_php_version_mismatch', 'PHP mismatch must block sync' );

$canonical = Leadwerk_Migration_Sync_Hub::canonical_request( 'post', '/leadwerk/v1/hub/heartbeat', 123, str_repeat( 'a', 32 ), '{"ok":true}' );
leadwerk_sync_assert( substr_count( $canonical, "\n" ) === 4 && strpos( $canonical, 'POST' ) === 0, 'signed request canonicalization must be stable' );

$scheduler_source = file_get_contents( dirname( __DIR__ ) . '/lib/model/class-leadwerk_migration-scheduler.php' );
$sync_source      = file_get_contents( dirname( __DIR__ ) . '/lib/model/class-leadwerk_migration-sync.php' );
$controller_source = file_get_contents( dirname( __DIR__ ) . '/lib/controller/class-leadwerk_migration-sync-controller.php' );
leadwerk_sync_assert( is_string( $scheduler_source ) && strpos( $scheduler_source, "'sync' === \$origin ? array()" ) !== false, 'Site Sync exports must ignore routine backup exclusions' );
leadwerk_sync_assert( is_string( $sync_source ) && substr_count( $sync_source, "Leadwerk_Migration_Scheduler::run( 'sync' )" ) === 2, 'source and target safety exports must both use full sync mode' );
leadwerk_sync_assert( is_string( $controller_source ) && strpos( $controller_source, 'SYNC LIVE' ) === false, 'typed live approval must not remain in the zero-touch transfer controller' );

fwrite( STDOUT, "Leadwerk Site Sync smoke tests passed.\n" );
