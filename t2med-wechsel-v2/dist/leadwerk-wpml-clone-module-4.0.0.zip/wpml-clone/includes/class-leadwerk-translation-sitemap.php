<?php
/** Keep published EN counterparts in sitemaps without exposing drafts. */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class Leadwerk_Translation_Sitemap {
	public static function init() {
		add_filter( 'wp_sitemaps_posts_query_args', array( __CLASS__, 'query_args' ), 20, 2 );
		add_filter( 'wpseo_sitemap_entry', array( __CLASS__, 'yoast_entry' ), 20, 3 );
	}

	public static function query_args( $args, $post_type ) {
		if ( 'page' === $post_type ) {
			$args['post_status'] = array( 'publish' );
		}
		return $args;
	}

	/** Yoast accepts extra data keys; alternates are available to compatible XSL/extensions. */
	public static function yoast_entry( $url, $type, $object ) {
		if ( 'post' !== $type || ! $object instanceof WP_Post || 'page' !== $object->post_type ) {
			return $url;
		}
		$translations = Leadwerk_Translation_API::translations( $object->ID, true );
		if ( count( $translations ) < 2 ) {
			return $url;
		}
		$url['alternates'] = array();
		foreach ( $translations as $language => $post_id ) {
			$url['alternates'][ $language ] = Leadwerk_Translation_API::public_url( $post_id );
		}
		return $url;
	}
}
