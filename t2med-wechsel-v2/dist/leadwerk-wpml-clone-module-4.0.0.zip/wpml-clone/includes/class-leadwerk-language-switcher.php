<?php
/** Widget, shortcode and template helper for published language pairs. */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class Leadwerk_Language_Switcher extends WP_Widget {
	public function __construct() {
		parent::__construct( 'leadwerk_language_switcher', 'Leadwerk Language Switcher', array( 'description' => 'Zeigt nur veröffentlichte Sprachgegenstücke.' ) );
	}

	public static function init() {
		add_action( 'widgets_init', array( __CLASS__, 'register_widget' ) );
		add_shortcode( 'leadwerk_language_switcher', array( __CLASS__, 'shortcode' ) );
	}

	public static function register_widget() { register_widget( __CLASS__ ); }

	public function widget( $args, $instance ) {
		echo wp_kses_post( $args['before_widget'] ?? '' );
		echo self::render( $instance ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Escaped by render().
		echo wp_kses_post( $args['after_widget'] ?? '' );
	}

	public function form( $instance ) {
		$style = sanitize_key( (string) ( $instance['style'] ?? 'compact' ) );
		?>
		<p><label for="<?php echo esc_attr( $this->get_field_id( 'style' ) ); ?>">Darstellung</label>
		<select id="<?php echo esc_attr( $this->get_field_id( 'style' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'style' ) ); ?>">
			<option value="compact" <?php selected( $style, 'compact' ); ?>>DE / EN</option>
			<option value="names" <?php selected( $style, 'names' ); ?>>Sprachnamen</option>
		</select></p>
		<?php
	}

	public function update( $new_instance, $old_instance ) {
		$style = sanitize_key( (string) ( $new_instance['style'] ?? 'compact' ) );
		return array( 'style' => in_array( $style, array( 'compact', 'names' ), true ) ? $style : 'compact' );
	}

	public static function shortcode( $atts ) {
		$atts = shortcode_atts( array( 'style' => 'compact' ), $atts, 'leadwerk_language_switcher' );
		return self::render( $atts );
	}

	public static function render( $options = array() ) {
		$urls = class_exists( 'Leadwerk_Translation_Router' ) ? Leadwerk_Translation_Router::get_current_page_alternate_urls() : array();
		if ( count( $urls ) < 2 ) {
			return '';
		}
		$style   = 'names' === sanitize_key( (string) ( $options['style'] ?? 'compact' ) ) ? 'names' : 'compact';
		$current = Leadwerk_Translation_API::current_language();
		$html    = '<nav class="leadwerk-language-switcher leadwerk-language-switcher--' . esc_attr( $style ) . '" aria-label="Language">';
		foreach ( array( 'de' => 'Deutsch', 'en' => 'English' ) as $code => $name ) {
			$label = 'names' === $style ? $name : strtoupper( $code );
			$html .= '<a class="leadwerk-language-switcher__link' . ( $current === $code ? ' is-active' : '' ) . '" href="' . esc_url( $urls[ $code ] ) . '" hreflang="' . esc_attr( $code ) . '" lang="' . esc_attr( $code ) . '"' . ( $current === $code ? ' aria-current="page"' : '' ) . '>' . esc_html( $label ) . '</a>';
		}
		return $html . '</nav>';
	}
}

if ( ! function_exists( 'leadwerk_language_switcher' ) ) {
	function leadwerk_language_switcher( $options = array() ) {
		echo Leadwerk_Language_Switcher::render( $options ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
	}
}
