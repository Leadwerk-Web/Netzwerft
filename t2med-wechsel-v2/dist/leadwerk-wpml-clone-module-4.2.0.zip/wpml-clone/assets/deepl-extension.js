(function () {
    "use strict";

    var ICON_SELECTOR = '[data-qa="input-translation-icon"],.dl-icon-circle.dl-icon[data-qa="input-translation-icon"],.dl-input-placeholder [data-tooltip*="Ctrl+Shift+Y"],.dl-input-placeholder [data-tooltip*="Translate"],.dl-input-placeholder [data-tooltip*="bersetzen"],.dl-input-placeholder [data-tooltip*="Übersetzen"]';
    var ICON_TRIGGER_SELECTOR = '[data-qa="input-translation-icon"],.dl-icon-circle.dl-icon[data-qa="input-translation-icon"]';
    var ICON_TOOLTIP_SELECTOR = '[data-tooltip*="Ctrl+Shift+Y"],[data-tooltip*="Translate"],[data-tooltip*="bersetzen"],[data-tooltip*="Übersetzen"]';
    var OVERLAY_SELECTOR = '.dl-input-positioner,.dl-input-placeholder,.dl-input-translation-container';
    var LOADING_SELECTOR = '.dl-loading';
    var LENGTH_LIMIT = 1500;
    var SAFE_BATCH_SIZE = 2;
    var ICON_WAIT_MS = 2200;
    var TRANSLATION_WAIT_MS = 9000;
    var SETTLE_WAIT_MS = 800;
    var state = { active: false, stop: false, form: null };

    function sleep(ms) {
        return new Promise(function (resolve) { window.setTimeout(resolve, ms); });
    }

    function randomBetween(min, max) {
        return min + Math.floor(Math.random() * ((max - min) + 1));
    }

    function normalize(value) {
        return (value || "").replace(/\s+/g, " ").trim();
    }

    function sourceLengthBonus(length) {
        if (length < 280) return 0;
        if (length < 700) return randomBetween(120, 320);
        if (length < 1100) return randomBetween(280, 620);
        return randomBetween(520, 980);
    }

    function triggerUpdate(field) {
        field.dispatchEvent(new Event("input", { bubbles: true }));
        field.dispatchEvent(new Event("change", { bubbles: true }));
    }

    function isVisible(element) {
        if (!element || !(element instanceof Element) || element.hidden || element.getAttribute("aria-hidden") === "true") return false;
        var style = window.getComputedStyle(element);
        return style.display !== "none" && style.visibility !== "hidden" && parseFloat(style.opacity || "1") !== 0 && element.getClientRects().length > 0;
    }

    function uniquePush(list, element) {
        if (element && element instanceof Element && list.indexOf(element) === -1) list.push(element);
    }

    function searchRoots() {
        var roots = [];
        var queue = [document];
        while (queue.length) {
            var root = queue.shift();
            if (!root || roots.indexOf(root) !== -1) continue;
            roots.push(root);
            if (!root.querySelectorAll) continue;
            Array.prototype.forEach.call(root.querySelectorAll("*"), function (node) {
                if (node.shadowRoot && roots.indexOf(node.shadowRoot) === -1) queue.push(node.shadowRoot);
            });
        }
        return roots;
    }

    function collect(selector) {
        var matches = [];
        searchRoots().forEach(function (root) {
            if (!root.querySelectorAll) return;
            try {
                Array.prototype.forEach.call(root.querySelectorAll(selector), function (node) { uniquePush(matches, node); });
            } catch (error) {}
        });
        return matches;
    }

    function tooltipText(node) {
        if (!node || !(node instanceof Element)) return "";
        if (node.getAttribute("data-tooltip")) return node.getAttribute("data-tooltip") || "";
        var owner = node.closest ? node.closest("[data-tooltip]") : null;
        return owner ? (owner.getAttribute("data-tooltip") || "") : "";
    }

    function isTranslateTooltip(text) {
        return /ctrl\s*\+\s*shift\s*\+\s*y|translate|ubersetzen|[Üü]bersetzen/i.test(text || "");
    }

    function normalizeIcon(node) {
        if (!node || !(node instanceof Element)) return null;
        if (node.matches(ICON_TRIGGER_SELECTOR)) return node;
        var direct = node.closest ? node.closest(ICON_TRIGGER_SELECTOR) : null;
        if (direct) return direct;
        var tooltip = node.matches(ICON_TOOLTIP_SELECTOR) ? node : (node.closest ? node.closest(ICON_TOOLTIP_SELECTOR) : null);
        if (!tooltip || !isTranslateTooltip(tooltipText(tooltip))) return null;
        return (tooltip.closest && (tooltip.closest(ICON_TRIGGER_SELECTOR) || tooltip.closest(".dl-icon-circle.dl-icon"))) || tooltip.parentElement;
    }

    function normalizeOverlay(node) {
        if (!node || !(node instanceof Element)) return null;
        if (node.matches(".dl-input-positioner")) return node;
        if (!node.closest) return null;
        var positioner = node.closest(".dl-input-positioner");
        if (positioner) return positioner;
        var container = node.closest(".dl-input-translation-container");
        if (container) return container.querySelector(".dl-input-positioner") || container;
        var placeholder = node.closest(".dl-input-placeholder");
        return placeholder ? (placeholder.closest(".dl-input-positioner") || placeholder) : null;
    }

    function verticalOverlap(a, b) {
        return a.bottom >= b.top && b.bottom >= a.top;
    }

    function targetScore(fieldRect, targetRect) {
        var desiredX = fieldRect.left + (fieldRect.width * 0.8);
        var score = Math.abs((fieldRect.top + fieldRect.height / 2) - (targetRect.top + targetRect.height / 2));
        score += Math.abs(desiredX - (targetRect.left + targetRect.width / 2));
        if (!verticalOverlap(fieldRect, targetRect)) score += 2500;
        if (targetRect.left < fieldRect.left + fieldRect.width * 0.45) score += 500;
        return score;
    }

    function overlayIcons(overlay) {
        var icons = [];
        if (!overlay || !overlay.querySelectorAll) return icons;
        Array.prototype.forEach.call(overlay.querySelectorAll(ICON_SELECTOR + "," + ICON_TOOLTIP_SELECTOR), function (node) {
            var icon = normalizeIcon(node);
            if (isVisible(icon)) uniquePush(icons, icon);
        });
        return icons;
    }

    function findTargets(field) {
        var fieldRect = field.getBoundingClientRect();
        var matches = [];
        var iconsSeen = [];
        collect(OVERLAY_SELECTOR).forEach(function (node) {
            var overlay = normalizeOverlay(node) || node;
            if (!isVisible(overlay)) return;
            overlayIcons(overlay).forEach(function (icon) {
                if (iconsSeen.indexOf(icon) !== -1) return;
                iconsSeen.push(icon);
                matches.push({ icon: icon, overlay: overlay, score: targetScore(fieldRect, overlay.getBoundingClientRect()) });
            });
        });
        collect(ICON_SELECTOR + "," + ICON_TOOLTIP_SELECTOR).forEach(function (node) {
            var icon = normalizeIcon(node);
            if (!isVisible(icon) || iconsSeen.indexOf(icon) !== -1) return;
            var overlay = normalizeOverlay(icon);
            var rect = overlay ? overlay.getBoundingClientRect() : icon.getBoundingClientRect();
            iconsSeen.push(icon);
            matches.push({ icon: icon, overlay: overlay, score: targetScore(fieldRect, rect) + (overlay ? 0 : 1200) });
        });
        matches.sort(function (a, b) { return a.score - b.score; });
        return matches.slice(0, 2);
    }

    async function waitForTarget(field, timeout) {
        var started = Date.now();
        while (Date.now() - started < timeout) {
            var targets = findTargets(field);
            if (targets.length) return targets;
            await sleep(150);
        }
        return [];
    }

    function scrollSnapshot() {
        var element = document.scrollingElement || document.documentElement;
        return { x: element.scrollLeft, y: element.scrollTop };
    }

    function restoreScroll(snapshot) {
        if (!snapshot) return;
        var element = document.scrollingElement || document.documentElement;
        element.scrollLeft = snapshot.x;
        element.scrollTop = snapshot.y;
        window.scrollTo(snapshot.x, snapshot.y);
    }

    function stabilizeScroll(snapshot) {
        restoreScroll(snapshot);
        window.setTimeout(function () { restoreScroll(snapshot); }, 40);
        window.setTimeout(function () { restoreScroll(snapshot); }, 160);
    }

    function pointerClick(target) {
        var rect = target.getBoundingClientRect();
        var init = { bubbles: true, cancelable: true, view: window, clientX: rect.left + rect.width / 2, clientY: rect.top + rect.height / 2, button: 0, buttons: 1 };
        try {
            ["pointerover", "pointerenter", "pointermove", "pointerdown", "pointerup"].forEach(function (type) { target.dispatchEvent(new PointerEvent(type, init)); });
        } catch (error) {}
        ["mouseover", "mouseenter", "mousemove", "mousedown", "mouseup", "click"].forEach(function (type) { target.dispatchEvent(new MouseEvent(type, init)); });
    }

    function nativeClick(icon, snapshot) {
        var target = normalizeIcon(icon) || icon;
        if (!isVisible(target)) return false;
        try { target.focus({ preventScroll: true }); } catch (error) { try { target.focus(); } catch (ignored) {} }
        try {
            if (typeof target.click === "function") target.click();
            else pointerClick(target);
        } catch (error) { pointerClick(target); }
        stabilizeScroll(snapshot);
        return true;
    }

    function prepareField(field) {
        field.scrollIntoView({ block: "center", inline: "nearest" });
        try { field.focus({ preventScroll: true }); } catch (error) { field.focus(); }
        var length = field.value.length;
        if (typeof field.setSelectionRange === "function") field.setSelectionRange(length, length);
        pointerClick(field);
        if (typeof field.select === "function") field.select();
        if (typeof field.setSelectionRange === "function") field.setSelectionRange(0, length);
    }

    function loading(overlay) {
        return !!overlay && !!overlay.querySelector && isVisible(overlay.querySelector(LOADING_SELECTOR));
    }

    async function waitForTranslation(field, baseline, overlay, timeout) {
        var original = normalize(baseline);
        var started = Date.now();
        var sawLoading = false;
        while (Date.now() - started < timeout) {
            if (normalize(field.value) && normalize(field.value) !== original) {
                await sleep(SETTLE_WAIT_MS);
                return true;
            }
            sawLoading = sawLoading || loading(overlay);
            await sleep(sawLoading ? 250 : 150);
        }
        return false;
    }

    function setStatus(form, active, message) {
        state.active = active;
        form.querySelectorAll("[data-lw-machine],[data-lw-machine-section],[data-lw-machine-all]").forEach(function (button) { button.disabled = active; });
        var cancel = form.querySelector("[data-lw-machine-cancel]");
        if (cancel) { cancel.hidden = !active; cancel.textContent = "Abbrechen"; }
        var status = form.querySelector(".lw-machine-progress");
        if (!status) {
            status = document.createElement("p");
            status.className = "lw-machine-progress";
            status.setAttribute("role", "status");
            form.prepend(status);
        }
        status.textContent = message || "";
    }

    function itemForSegment(segment) {
        return { segment: segment, source: segment.querySelector("[data-lw-source]"), target: segment.querySelector("[data-lw-target]") };
    }

    function collectItems(scope, includeFilled) {
        var items = Array.prototype.map.call(scope.querySelectorAll(".lw-segment"), itemForSegment).filter(function (item) {
            if (!item.source || !item.target || !item.source.value.trim()) return false;
            return includeFilled || !item.target.value.trim() || item.segment.dataset.status === "needs_review";
        });
        var titleSource = scope.querySelector("[data-lw-title-source]");
        var titleTarget = scope.querySelector("[data-lw-title-target]");
        var titleIsPlaceholder = titleSource && titleTarget && (titleTarget.value.trim() === titleSource.value.trim() || /\s*\(EN\)\s*$/.test(titleTarget.value));
        if (titleSource && titleTarget && titleSource.value.trim() && (includeFilled || !titleTarget.value.trim() || titleIsPlaceholder)) {
            items.unshift({ segment: null, source: titleSource, target: titleTarget });
        }
        return items;
    }

    async function translateItem(item) {
        var source = item.source.value || "";
        if (source.length >= LENGTH_LIMIT) return "too_long";
        item.target.value = source;
        triggerUpdate(item.target);
        prepareField(item.target);
        var snapshot = scrollSnapshot();
        await sleep(randomBetween(840, 1860) + sourceLengthBonus(source.length));
        var targets = await waitForTarget(item.target, ICON_WAIT_MS + sourceLengthBonus(source.length));
        if (!targets.length) return "no_icon";
        for (var index = 0; index < targets.length; index += 1) {
            prepareField(item.target);
            await sleep(randomBetween(360, 780));
            if (!nativeClick(targets[index].icon, snapshot)) continue;
            if (await waitForTranslation(item.target, source, targets[index].overlay, TRANSLATION_WAIT_MS + sourceLengthBonus(source.length) * 4)) {
                triggerUpdate(item.target);
                stabilizeScroll(snapshot);
                return "translated";
            }
        }
        triggerUpdate(item.target);
        stabilizeScroll(snapshot);
        return "timed_out";
    }

    async function cooldown(form, seconds, progress) {
        for (var remaining = seconds; remaining > 0; remaining -= 1) {
            if (state.stop) return;
            setStatus(form, true, progress + " · Sicherheits-Pause " + remaining + "s");
            await sleep(1000);
        }
    }

    async function run(form, items) {
        if (state.active || !items.length) return;
        state.stop = false;
        state.form = form;
        var counts = { translated: 0, too_long: 0, no_icon: 0, timed_out: 0 };
        setStatus(form, true, "DeepL-Browsererweiterung wird vorbereitet …");
        for (var index = 0; index < items.length; index += 1) {
            if (state.stop) break;
            setStatus(form, true, "DeepL " + (index + 1) + "/" + items.length + " · übersetzt " + counts.translated);
            var result;
            try { result = await translateItem(items[index]); } catch (error) { result = "timed_out"; }
            counts[result] = (counts[result] || 0) + 1;
            await sleep(randomBetween(900, 1700));
            if (!state.stop && (index + 1) < items.length && (index + 1) % SAFE_BATCH_SIZE === 0) {
                var failed = result !== "translated" && result !== "too_long";
                await cooldown(form, randomBetween(failed ? 25 : 12, failed ? 45 : 24), "DeepL " + (index + 1) + "/" + items.length);
            }
        }
        var message = (state.stop ? "Gestoppt. " : "Fertig. ") + "Übersetzt: " + counts.translated + ", zu lang: " + counts.too_long + ", Icon fehlt: " + counts.no_icon + ", Timeout: " + counts.timed_out + ". Bitte prüfen und speichern.";
        if (counts.no_icon && !counts.translated) message += " Die offizielle DeepL-Browsererweiterung ist nicht aktiv oder darf auf dieser WordPress-Seite nicht ausgeführt werden.";
        setStatus(form, false, message);
        state.stop = false;
        state.form = null;
    }

    document.addEventListener("click", function (event) {
        var cancel = event.target.closest("[data-lw-machine-cancel]");
        if (cancel) {
            event.preventDefault();
            state.stop = true;
            cancel.textContent = "Wird gestoppt …";
            return;
        }
        var button = event.target.closest("[data-lw-machine],[data-lw-machine-section],[data-lw-machine-all]");
        if (!button) return;
        event.preventDefault();
        var form = button.closest(".lw-segment-form");
        if (!form) return;
        var scope = button.matches("[data-lw-machine]") ? button.closest(".lw-segment") : (button.matches("[data-lw-machine-section]") ? button.closest(".lw-section") : form);
        var items = button.matches("[data-lw-machine]") ? [itemForSegment(scope)] : collectItems(scope, false);
        if (button.matches("[data-lw-machine]") && items[0].target.value.trim() && !window.confirm("Mevcut EN metni DeepL çevirisiyle değiştirilsin mi?")) return;
        run(form, items);
    });
})();
