<?php
/** Leadwerk Site Sync administration view. */
if ( ! defined( 'ABSPATH' ) ) {
	die( 'Direct access is not allowed.' );
}

$has_family = is_array( $family ) && Leadwerk_Migration_Site_Identity::valid_id( isset( $family['family_id'] ) ? $family['family_id'] : '' );
$registration = isset( $environment['registration'] ) ? $environment['registration'] : 'unregistered';
$approved_environments = array_values(
	array_filter(
		is_array( $directory ) ? $directory : array(),
		static function ( $item ) {
			return is_array( $item ) && isset( $item['status'] ) && 'approved' === $item['status'];
		}
	)
);
$format_seen = static function ( $row ) {
	if ( ! is_array( $row ) || empty( $row['last_seen_at'] ) ) {
		return __( 'Never', 'leadwerk-migration' );
	}
	$timestamp = strtotime( $row['last_seen_at'] . ' UTC' );
	return false === $timestamp ? __( 'Unknown', 'leadwerk-migration' ) : sprintf( __( '%s ago', 'leadwerk-migration' ), human_time_diff( $timestamp, time() ) );
};
$environment_labels = array( 'local' => __( 'Local', 'leadwerk-migration' ), 'staging' => __( 'Staging', 'leadwerk-migration' ), 'live' => __( 'Live', 'leadwerk-migration' ) );
$registry_actions = static function ( $kind, $id, $status ) {
	$approve = 'approved' !== $status;
	$action = $approve ? 'leadwerk_migration_hub_approve' : 'leadwerk_migration_hub_revoke';
	ob_start();
	?>
	<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>"><input type="hidden" name="action" value="<?php echo esc_attr( $action ); ?>" /><input type="hidden" name="kind" value="<?php echo esc_attr( $kind ); ?>" /><input type="hidden" name="registry_id" value="<?php echo esc_attr( $id ); ?>" /><?php wp_nonce_field( $action ); ?><button class="button button-small" type="submit"><?php echo esc_html( $approve ? __( 'Approve', 'leadwerk-migration' ) : __( 'Revoke', 'leadwerk-migration' ) ); ?></button></form>
	<?php
	return ob_get_clean();
};
?>

<div class="wrap leadwerk-dashboard leadwerk-sync">
	<?php if ( ! empty( $notice['message'] ) ) : ?>
		<div class="notice notice-<?php echo esc_attr( isset( $notice['type'] ) ? $notice['type'] : 'info' ); ?> is-dismissible"><p><?php echo esc_html( $notice['message'] ); ?></p></div>
	<?php endif; ?>
	<?php if ( $remote_error !== '' ) : ?>
		<div class="notice notice-warning"><p><strong><?php esc_html_e( 'Hub connection:', 'leadwerk-migration' ); ?></strong> <?php echo esc_html( $remote_error ); ?></p></div>
	<?php endif; ?>

	<header class="leadwerk-dashboard__hero leadwerk-dashboard__hero--compact">
		<div>
			<p class="leadwerk-dashboard__eyebrow"><?php esc_html_e( 'FULL WORDPRESS ENVIRONMENT TRANSFER', 'leadwerk-migration' ); ?></p>
			<h1><?php esc_html_e( 'Leadwerk Site Sync', 'leadwerk-migration' ); ?></h1>
			<p><?php esc_html_e( 'Local, staging and live make signed outbound requests to Leadwerk Hub. No inbound connection to a local computer and no second environment approval are required.', 'leadwerk-migration' ); ?></p>
		</div>
		<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
			<input type="hidden" name="action" value="leadwerk_migration_sync_process" />
			<?php wp_nonce_field( 'leadwerk_migration_sync_process' ); ?>
			<button class="button button-primary" type="submit" <?php disabled( ! $has_family || 'approved' !== $registration ); ?>><?php esc_html_e( 'Run worker now', 'leadwerk-migration' ); ?></button>
		</form>
	</header>

	<div class="leadwerk-dashboard__metrics">
		<div class="leadwerk-metric"><span><?php esc_html_e( 'This environment', 'leadwerk-migration' ); ?></span><strong><?php echo esc_html( isset( $environment_labels[ $environment['type'] ] ) ? $environment_labels[ $environment['type'] ] : ucfirst( $environment['type'] ) ); ?></strong><small><?php echo esc_html( Leadwerk_Migration_Site_Identity::normalized_site_url() ); ?></small></div>
		<div class="leadwerk-metric"><span><?php esc_html_e( 'Runtime versions', 'leadwerk-migration' ); ?></span><strong><?php echo esc_html( get_bloginfo( 'version' ) ); ?></strong><small><?php echo esc_html( 'PHP ' . PHP_VERSION . ' · Plugin ' . LEADWERK_MIGRATION_VERSION ); ?></small></div>
		<div class="leadwerk-metric"><span><?php esc_html_e( 'Hub registration', 'leadwerk-migration' ); ?></span><strong class="leadwerk-state <?php echo 'approved' === $registration ? 'is-active' : ''; ?>"><?php echo esc_html( ucwords( str_replace( '_', ' ', $registration ) ) ); ?></strong><small><?php echo esc_html( $settings['hub_url'] ); ?></small></div>
	</div>

	<?php if ( ! $has_family ) : ?>
		<section class="leadwerk-panel leadwerk-panel--zone-zero">
			<div class="leadwerk-panel__header"><div><h2><?php esc_html_e( 'Create Zone Zero', 'leadwerk-migration' ); ?></h2><p><?php esc_html_e( 'This creates the permanent Site Family identity and its first verified full backup together. Install that backup on new local, staging or live WordPress instances to carry the same family identity.', 'leadwerk-migration' ); ?></p></div><span class="leadwerk-badge leadwerk-badge--warning"><?php esc_html_e( 'Not initialized', 'leadwerk-migration' ); ?></span></div>
			<form class="leadwerk-settings leadwerk-sync__inline-form" method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
				<input type="hidden" name="action" value="leadwerk_migration_sync_initialize" />
				<?php wp_nonce_field( 'leadwerk_migration_sync_initialize' ); ?>
				<label><span><?php esc_html_e( 'Project name', 'leadwerk-migration' ); ?></span><input type="text" name="project_name" maxlength="190" value="<?php echo esc_attr( get_bloginfo( 'name' ) ); ?>" required /></label>
				<button class="button button-primary" type="submit"><?php esc_html_e( 'Create Zone Zero backup', 'leadwerk-migration' ); ?></button>
			</form>
		</section>
	<?php else : ?>
		<div class="leadwerk-dashboard__grid leadwerk-dashboard__grid--sync">
			<section class="leadwerk-panel">
				<div class="leadwerk-panel__header"><div><h2><?php esc_html_e( 'Site Family identity', 'leadwerk-migration' ); ?></h2><p><?php esc_html_e( 'Secrets are never shown in the browser. Each environment has its own credential.', 'leadwerk-migration' ); ?></p></div><span class="leadwerk-badge leadwerk-badge--verified"><?php esc_html_e( 'Zone Zero linked', 'leadwerk-migration' ); ?></span></div>
				<dl class="leadwerk-status-list">
					<div><dt><?php esc_html_e( 'Project', 'leadwerk-migration' ); ?></dt><dd><?php echo esc_html( isset( $family['project_name'] ) ? $family['project_name'] : '' ); ?></dd></div>
					<div><dt><?php esc_html_e( 'Family ID', 'leadwerk-migration' ); ?></dt><dd><code><?php echo esc_html( $family['family_id'] ); ?></code></dd></div>
					<div><dt><?php esc_html_e( 'Environment ID', 'leadwerk-migration' ); ?></dt><dd><code><?php echo esc_html( $environment['environment_id'] ); ?></code></dd></div>
					<?php if ( ! empty( $environment['promoted_at'] ) ) : ?><div><dt><?php esc_html_e( 'Promoted to live', 'leadwerk-migration' ); ?></dt><dd><?php echo esc_html( $environment['promoted_at'] ); ?></dd></div><?php endif; ?>
					<div><dt><?php esc_html_e( 'Heartbeat', 'leadwerk-migration' ); ?></dt><dd><?php esc_html_e( 'Every 5 minutes; offline after 15 minutes', 'leadwerk-migration' ); ?></dd></div>
				</dl>
				<div class="leadwerk-callout"><strong><?php esc_html_e( 'WP-Cron note', 'leadwerk-migration' ); ?></strong><p><?php esc_html_e( 'WordPress cron needs site traffic. Configure the host to call wp-cron.php every five minutes when exact online monitoring is required.', 'leadwerk-migration' ); ?></p></div>
				<?php if ( isset( $environment['type'] ) && 'staging' === $environment['type'] ) : ?>
					<div class="leadwerk-sync__promotion">
						<h3><?php esc_html_e( 'Promote this staging installation', 'leadwerk-migration' ); ?></h3>
						<p><?php esc_html_e( 'Use this when the customer domain is now attached but automatic detection cannot identify the change. The environment ID and sync history are preserved.', 'leadwerk-migration' ); ?></p>
						<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
							<input type="hidden" name="action" value="leadwerk_migration_sync_promote_live" /><?php wp_nonce_field( 'leadwerk_migration_sync_promote_live' ); ?>
							<label><span><?php esc_html_e( 'Enter PROMOTE LIVE', 'leadwerk-migration' ); ?></span><input type="text" name="promotion_confirmation" autocomplete="off" required /></label>
							<button class="button" type="submit"><?php esc_html_e( 'Promote staging to live', 'leadwerk-migration' ); ?></button>
						</form>
					</div>
				<?php endif; ?>
			</section>
			<aside class="leadwerk-panel leadwerk-panel--quick">
				<div class="leadwerk-panel__header"><div><h2><?php esc_html_e( 'Hub connection', 'leadwerk-migration' ); ?></h2><p><?php esc_html_e( 'Registration is approved centrally once. Individual sync jobs do not require approval from both environments.', 'leadwerk-migration' ); ?></p></div></div>
				<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
					<input type="hidden" name="action" value="leadwerk_migration_sync_register" />
					<?php wp_nonce_field( 'leadwerk_migration_sync_register' ); ?>
					<button class="button button-primary button-hero" type="submit"><?php echo esc_html( 'unregistered' === $registration ? __( 'Register with Hub', 'leadwerk-migration' ) : __( 'Refresh Hub registration', 'leadwerk-migration' ) ); ?></button>
				</form>
			</aside>
		</div>
	<?php endif; ?>

	<section class="leadwerk-panel">
		<div class="leadwerk-panel__header"><div><h2><?php esc_html_e( 'Environments and heartbeat', 'leadwerk-migration' ); ?></h2><p><?php esc_html_e( 'All environments ping Leadwerk Hub every five minutes. Direct environment-to-environment network access is not used.', 'leadwerk-migration' ); ?></p></div><span class="leadwerk-badge"><?php echo esc_html( sprintf( __( '%d environments', 'leadwerk-migration' ), count( $directory ) ) ); ?></span></div>
		<?php if ( $directory ) : ?>
			<div class="leadwerk-table-wrap"><table class="widefat striped leadwerk-table"><thead><tr><th><?php esc_html_e( 'Environment', 'leadwerk-migration' ); ?></th><th><?php esc_html_e( 'Status', 'leadwerk-migration' ); ?></th><th><?php esc_html_e( 'Last heartbeat', 'leadwerk-migration' ); ?></th><th><?php esc_html_e( 'WordPress', 'leadwerk-migration' ); ?></th><th><?php esc_html_e( 'PHP', 'leadwerk-migration' ); ?></th><th><?php esc_html_e( 'Plugin', 'leadwerk-migration' ); ?></th></tr></thead><tbody>
			<?php foreach ( $directory as $item ) : ?>
				<tr><td><strong><?php echo esc_html( isset( $environment_labels[ $item['environment_type'] ] ) ? $environment_labels[ $item['environment_type'] ] : ucfirst( $item['environment_type'] ) ); ?></strong><br /><small><?php echo esc_html( $item['site_url'] ); ?></small></td><td><span class="leadwerk-badge <?php echo ! empty( $item['is_online'] ) ? 'leadwerk-badge--verified' : 'leadwerk-badge--modified'; ?>"><span class="leadwerk-state-dot <?php echo empty( $item['is_online'] ) ? 'is-offline' : ''; ?>"></span><?php echo esc_html( ! empty( $item['is_online'] ) ? __( 'Online', 'leadwerk-migration' ) : __( 'Offline', 'leadwerk-migration' ) ); ?></span></td><td><?php echo esc_html( $format_seen( $item ) ); ?></td><td><?php echo esc_html( $item['wordpress_version'] ); ?></td><td><?php echo esc_html( $item['php_version'] ); ?></td><td><?php echo esc_html( $item['plugin_version'] ); ?></td></tr>
			<?php endforeach; ?>
			</tbody></table></div>
		<?php else : ?><div class="leadwerk-empty"><span class="dashicons dashicons-admin-site-alt3" aria-hidden="true"></span><h3><?php esc_html_e( 'No approved environment directory yet', 'leadwerk-migration' ); ?></h3><p><?php esc_html_e( 'Create Zone Zero, register this environment, then approve the family and environment once in the Hub panel.', 'leadwerk-migration' ); ?></p></div><?php endif; ?>
	</section>

	<section class="leadwerk-panel leadwerk-sync__transfer">
		<div class="leadwerk-panel__header"><div><h2><?php esc_html_e( 'Start full-site synchronization', 'leadwerk-migration' ); ?></h2><p><?php esc_html_e( 'The first gate compares exact WordPress, PHP and Leadwerk Migration versions. A mismatch blocks the job before any backup or destination change.', 'leadwerk-migration' ); ?></p></div><span class="leadwerk-badge leadwerk-badge--warning"><?php esc_html_e( 'Destructive on target', 'leadwerk-migration' ); ?></span></div>
		<form class="leadwerk-settings" id="leadwerk-sync-transfer" method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
			<input type="hidden" name="action" value="leadwerk_migration_sync_request" />
			<?php wp_nonce_field( 'leadwerk_migration_sync_request' ); ?>
			<div class="leadwerk-sync__direction">
				<label><span><?php esc_html_e( 'Source (will be backed up)', 'leadwerk-migration' ); ?></span><select name="source_environment_id" required><option value=""><?php esc_html_e( 'Choose source', 'leadwerk-migration' ); ?></option><?php foreach ( $approved_environments as $item ) : ?><option value="<?php echo esc_attr( $item['environment_id'] ); ?>" data-environment-type="<?php echo esc_attr( $item['environment_type'] ); ?>"><?php echo esc_html( strtoupper( $item['environment_type'] ) . ' · ' . $item['site_url'] ); ?></option><?php endforeach; ?></select></label>
				<span class="dashicons dashicons-arrow-right-alt" aria-hidden="true"></span>
				<label><span><?php esc_html_e( 'Target (will be replaced)', 'leadwerk-migration' ); ?></span><select name="target_environment_id" required><option value=""><?php esc_html_e( 'Choose target', 'leadwerk-migration' ); ?></option><?php foreach ( $approved_environments as $item ) : ?><option value="<?php echo esc_attr( $item['environment_id'] ); ?>" data-environment-type="<?php echo esc_attr( $item['environment_type'] ); ?>"><?php echo esc_html( strtoupper( $item['environment_type'] ) . ' · ' . $item['site_url'] ); ?></option><?php endforeach; ?></select></label>
			</div>
			<div class="leadwerk-sync__preflight"><strong><?php esc_html_e( 'Mandatory preflight order', 'leadwerk-migration' ); ?></strong><ol><li><?php esc_html_e( 'Exact WordPress version', 'leadwerk-migration' ); ?></li><li><?php esc_html_e( 'Exact PHP version', 'leadwerk-migration' ); ?></li><li><?php esc_html_e( 'Exact plugin version', 'leadwerk-migration' ); ?></li><li><?php esc_html_e( 'Both heartbeats newer than 15 minutes', 'leadwerk-migration' ); ?></li></ol></div>
			<div class="leadwerk-sync__live-confirm" id="leadwerk-live-confirm" hidden>
				<label><input type="checkbox" name="confirm_live" value="1" /> <?php esc_html_e( 'I understand that the current live WordPress files and database will be replaced after a safety backup.', 'leadwerk-migration' ); ?></label>
				<label><span><?php esc_html_e( 'Enter SYNC LIVE', 'leadwerk-migration' ); ?></span><input type="text" name="live_confirmation" autocomplete="off" /></label>
			</div>
			<div class="leadwerk-settings__footer"><button class="button button-primary" type="submit" <?php disabled( count( $approved_environments ) < 2 ); ?>><?php esc_html_e( 'Check versions and start sync', 'leadwerk-migration' ); ?></button></div>
		</form>
	</section>

	<section class="leadwerk-panel">
		<div class="leadwerk-panel__header"><div><h2><?php esc_html_e( 'Synchronization jobs', 'leadwerk-migration' ); ?></h2><p><?php esc_html_e( 'Transfers resume in encrypted, signed outbound batches. The Hub relay copy expires automatically.', 'leadwerk-migration' ); ?></p></div></div>
		<?php if ( $jobs ) : ?><div class="leadwerk-table-wrap"><table class="widefat striped leadwerk-table"><thead><tr><th><?php esc_html_e( 'Created', 'leadwerk-migration' ); ?></th><th><?php esc_html_e( 'Direction', 'leadwerk-migration' ); ?></th><th><?php esc_html_e( 'Status', 'leadwerk-migration' ); ?></th><th><?php esc_html_e( 'Progress', 'leadwerk-migration' ); ?></th><th><?php esc_html_e( 'Message', 'leadwerk-migration' ); ?></th></tr></thead><tbody>
		<?php foreach ( $jobs as $job ) : $size = isset( $job['archive_size'] ) ? (int) $job['archive_size'] : 0; $received = isset( $job['bytes_received'] ) ? (int) $job['bytes_received'] : 0; ?>
			<tr><td><?php echo esc_html( isset( $job['created_at'] ) ? $job['created_at'] . ' UTC' : '' ); ?></td><td><code><?php echo esc_html( substr( $job['source_environment_id'], 0, 8 ) ); ?></code> → <code><?php echo esc_html( substr( $job['target_environment_id'], 0, 8 ) ); ?></code></td><td><span class="leadwerk-badge leadwerk-badge--<?php echo esc_attr( sanitize_html_class( $job['status'] ) ); ?>"><?php echo esc_html( ucwords( str_replace( '_', ' ', $job['status'] ) ) ); ?></span></td><td><?php echo $size > 0 ? esc_html( size_format( $received ) . ' / ' . size_format( $size ) ) : '—'; ?></td><td><?php echo esc_html( isset( $job['message'] ) ? $job['message'] : '' ); ?></td></tr>
		<?php endforeach; ?></tbody></table></div><?php else : ?><div class="leadwerk-empty"><span class="dashicons dashicons-randomize" aria-hidden="true"></span><h3><?php esc_html_e( 'No sync jobs', 'leadwerk-migration' ); ?></h3><p><?php esc_html_e( 'Jobs appear here after the first version-compatible transfer is requested.', 'leadwerk-migration' ); ?></p></div><?php endif; ?>
	</section>

	<section class="leadwerk-panel">
		<div class="leadwerk-panel__header"><div><h2><?php esc_html_e( 'Site Sync settings', 'leadwerk-migration' ); ?></h2><p><?php esc_html_e( 'Automatic detection treats .local as local and myrdbx.io as staging. When the same installation receives a normal customer domain, its identity is preserved and its Hub type changes to live.', 'leadwerk-migration' ); ?></p></div></div>
		<form class="leadwerk-settings" method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
			<input type="hidden" name="action" value="leadwerk_migration_sync_save" /><?php wp_nonce_field( 'leadwerk_migration_sync_save' ); ?>
			<div class="leadwerk-field-grid">
				<label><span><?php esc_html_e( 'Project name', 'leadwerk-migration' ); ?></span><input type="text" name="project_name" maxlength="190" value="<?php echo esc_attr( isset( $family['project_name'] ) ? $family['project_name'] : get_bloginfo( 'name' ) ); ?>" /></label>
				<label><span><?php esc_html_e( 'Leadwerk Hub URL', 'leadwerk-migration' ); ?></span><input type="url" name="settings[hub_url]" value="<?php echo esc_attr( $settings['hub_url'] ); ?>" required /></label>
				<label><span><?php esc_html_e( 'Environment type', 'leadwerk-migration' ); ?></span><select name="settings[environment_type]"><?php foreach ( array( 'auto' => __( 'Automatic', 'leadwerk-migration' ), 'local' => __( 'Local', 'leadwerk-migration' ), 'staging' => __( 'Staging', 'leadwerk-migration' ), 'live' => __( 'Live', 'leadwerk-migration' ) ) as $value => $label ) : ?><option value="<?php echo esc_attr( $value ); ?>" <?php selected( $settings['environment_type'], $value ); ?>><?php echo esc_html( $label ); ?></option><?php endforeach; ?></select></label>
				<label><span><?php esc_html_e( 'Relay retention (hours)', 'leadwerk-migration' ); ?></span><input type="number" min="1" max="168" name="settings[relay_retention_hours]" value="<?php echo esc_attr( $settings['relay_retention_hours'] ); ?>" /></label>
			</div>
			<fieldset class="leadwerk-fieldset"><legend><?php esc_html_e( 'Central Hub role', 'leadwerk-migration' ); ?></legend><label><input type="hidden" name="settings[hub_mode]" value="0" /><input type="checkbox" name="settings[hub_mode]" value="1" <?php checked( ! empty( $settings['hub_mode'] ) ); ?> /> <?php esc_html_e( 'Enable registry and private relay on this WordPress (intended for leadwerk.de)', 'leadwerk-migration' ); ?></label><p><?php esc_html_e( 'When enabling for the first time, enter ENABLE HUB. Keep automatic approval disabled in production.', 'leadwerk-migration' ); ?></p><input type="text" name="hub_confirmation" placeholder="ENABLE HUB" autocomplete="off" /><label class="leadwerk-sync__check"><input type="hidden" name="settings[hub_auto_approve]" value="0" /><input type="checkbox" name="settings[hub_auto_approve]" value="1" <?php checked( ! empty( $settings['hub_auto_approve'] ) ); ?> /> <?php esc_html_e( 'Automatically approve new families/environments (development only)', 'leadwerk-migration' ); ?></label></fieldset>
			<div class="leadwerk-settings__footer"><button class="button button-primary" type="submit"><?php esc_html_e( 'Save settings', 'leadwerk-migration' ); ?></button></div>
		</form>
	</section>

	<?php if ( ! empty( $settings['hub_mode'] ) ) : ?>
		<section class="leadwerk-panel leadwerk-sync__hub-admin">
			<div class="leadwerk-panel__header"><div><h2><?php esc_html_e( 'Leadwerk Hub registry', 'leadwerk-migration' ); ?></h2><p><?php esc_html_e( 'Approve a Site Family and each environment once. This is account enrollment, not per-sync dual approval.', 'leadwerk-migration' ); ?></p></div><span class="leadwerk-badge leadwerk-badge--verified"><?php esc_html_e( 'Hub mode', 'leadwerk-migration' ); ?></span></div>
			<h3><?php esc_html_e( 'Site Families', 'leadwerk-migration' ); ?></h3>
			<div class="leadwerk-table-wrap"><table class="widefat striped leadwerk-table"><thead><tr><th><?php esc_html_e( 'Project', 'leadwerk-migration' ); ?></th><th><?php esc_html_e( 'Family ID', 'leadwerk-migration' ); ?></th><th><?php esc_html_e( 'Status', 'leadwerk-migration' ); ?></th><th></th></tr></thead><tbody><?php foreach ( $hub_data['families'] as $item ) : ?><tr><td><?php echo esc_html( $item['project_name'] ); ?></td><td><code><?php echo esc_html( $item['family_id'] ); ?></code></td><td><?php echo esc_html( $item['status'] ); ?></td><td><?php echo $registry_actions( 'family', $item['family_id'], $item['status'] ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?></td></tr><?php endforeach; ?></tbody></table></div>
			<h3><?php esc_html_e( 'Environments', 'leadwerk-migration' ); ?></h3>
			<div class="leadwerk-table-wrap"><table class="widefat striped leadwerk-table"><thead><tr><th><?php esc_html_e( 'URL', 'leadwerk-migration' ); ?></th><th><?php esc_html_e( 'Type', 'leadwerk-migration' ); ?></th><th><?php esc_html_e( 'Heartbeat', 'leadwerk-migration' ); ?></th><th><?php esc_html_e( 'Versions', 'leadwerk-migration' ); ?></th><th><?php esc_html_e( 'Status', 'leadwerk-migration' ); ?></th><th></th></tr></thead><tbody><?php foreach ( $hub_data['environments'] as $item ) : ?><tr><td><?php echo esc_html( $item['site_url'] ); ?></td><td><?php echo esc_html( $item['environment_type'] ); ?></td><td><span class="leadwerk-badge <?php echo ! empty( $item['is_online'] ) ? 'leadwerk-badge--verified' : 'leadwerk-badge--modified'; ?>"><?php echo esc_html( ! empty( $item['is_online'] ) ? __( 'Online', 'leadwerk-migration' ) : __( 'Offline', 'leadwerk-migration' ) ); ?></span> <?php echo esc_html( $format_seen( $item ) ); ?></td><td><?php echo esc_html( 'WP ' . $item['wordpress_version'] . ' · PHP ' . $item['php_version'] . ' · ' . $item['plugin_version'] ); ?></td><td><?php echo esc_html( $item['status'] ); ?></td><td><?php echo $registry_actions( 'environment', $item['environment_id'], $item['status'] ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?></td></tr><?php endforeach; ?></tbody></table></div>
		</section>
	<?php endif; ?>
</div>
