<?php
/**
 * Leadwerk central registry, signed job queue, and short-lived archive relay.
 *
 * Install this same plugin on leadwerk.de and enable Hub mode on the Site Sync
 * screen. Relay files are private, expire automatically, and are never exposed
 * through a direct public URL.
 *
 * Copyright (C) 2026 Leadwerk.
 * Licensed under GPLv3 or later.
 */

if ( ! defined( 'ABSPATH' ) ) {
	die( 'Direct access is not allowed.' );
}

class Leadwerk_Migration_Sync_Hub {

	const NAMESPACE = 'leadwerk/v1';
	const MAX_CLOCK_SKEW = 300;
	const ONLINE_TTL = 15 * MINUTE_IN_SECONDS;

	/** @return bool */
	public static function enabled() {
		$settings = Leadwerk_Migration_Site_Identity::settings();
		return ! empty( $settings['hub_mode'] );
	}

	/** Install or upgrade Hub tables when Hub mode is enabled. */
	public static function maybe_install() {
		if ( ! self::enabled() || get_option( LEADWERK_MIGRATION_SYNC_DB_OPTION, '' ) === LEADWERK_MIGRATION_SYNC_DB_VERSION ) {
			return;
		}

		global $wpdb;
		require_once ABSPATH . 'wp-admin/includes/upgrade.php';
		$charset = $wpdb->get_charset_collate();
		$tables  = self::tables();

		dbDelta( "CREATE TABLE {$tables['families']} (
			id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
			family_id char(32) NOT NULL,
			secret_hash varchar(255) NOT NULL,
			project_name varchar(190) NOT NULL,
			status varchar(20) NOT NULL DEFAULT 'pending',
			created_at datetime NOT NULL,
			updated_at datetime NOT NULL,
			PRIMARY KEY  (id),
			UNIQUE KEY family_id (family_id),
			KEY status (status)
		) {$charset};" );

		dbDelta( "CREATE TABLE {$tables['environments']} (
			id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
			environment_id char(32) NOT NULL,
			family_id char(32) NOT NULL,
			secret_encrypted longtext NOT NULL,
			site_url varchar(500) NOT NULL,
			environment_type varchar(20) NOT NULL,
			wordpress_version varchar(32) NOT NULL,
			php_version varchar(32) NOT NULL,
			plugin_version varchar(32) NOT NULL,
			fingerprint char(64) NOT NULL,
			status varchar(20) NOT NULL DEFAULT 'pending',
			created_at datetime NOT NULL,
			updated_at datetime NOT NULL,
			last_seen_at datetime NOT NULL,
			PRIMARY KEY  (id),
			UNIQUE KEY environment_id (environment_id),
			KEY family_id (family_id),
			KEY status (status)
		) {$charset};" );

		dbDelta( "CREATE TABLE {$tables['jobs']} (
			id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
			job_id char(32) NOT NULL,
			family_id char(32) NOT NULL,
			source_environment_id char(32) NOT NULL,
			target_environment_id char(32) NOT NULL,
			initiator_environment_id char(32) NOT NULL,
			status varchar(32) NOT NULL DEFAULT 'awaiting_approval',
			source_approved tinyint(1) NOT NULL DEFAULT 0,
			target_approved tinyint(1) NOT NULL DEFAULT 0,
			archive_name varchar(220) NOT NULL DEFAULT '',
			archive_size bigint(20) unsigned NOT NULL DEFAULT 0,
			archive_sha256 char(64) NOT NULL DEFAULT '',
			bytes_received bigint(20) unsigned NOT NULL DEFAULT 0,
			message text NOT NULL,
			created_at datetime NOT NULL,
			updated_at datetime NOT NULL,
			expires_at datetime NOT NULL,
			PRIMARY KEY  (id),
			UNIQUE KEY job_id (job_id),
			KEY family_id (family_id),
			KEY source_environment_id (source_environment_id),
			KEY target_environment_id (target_environment_id),
			KEY status (status)
		) {$charset};" );

		update_option( LEADWERK_MIGRATION_SYNC_DB_OPTION, LEADWERK_MIGRATION_SYNC_DB_VERSION, false );
		self::ensure_relay_directory();
	}

	/** Register public routes. Every route performs its own strict authorization. */
	public static function register_routes() {
		register_rest_route( self::NAMESPACE, '/hub/register', array( 'methods' => 'POST', 'callback' => array( __CLASS__, 'register_environment' ), 'permission_callback' => '__return_true' ) );
		register_rest_route( self::NAMESPACE, '/hub/heartbeat', array( 'methods' => 'POST', 'callback' => array( __CLASS__, 'heartbeat' ), 'permission_callback' => '__return_true' ) );
		register_rest_route( self::NAMESPACE, '/hub/directory', array( 'methods' => 'POST', 'callback' => array( __CLASS__, 'directory' ), 'permission_callback' => '__return_true' ) );
		register_rest_route( self::NAMESPACE, '/hub/jobs', array( 'methods' => 'POST', 'callback' => array( __CLASS__, 'create_job' ), 'permission_callback' => '__return_true' ) );
		register_rest_route( self::NAMESPACE, '/hub/jobs/list', array( 'methods' => 'POST', 'callback' => array( __CLASS__, 'list_jobs' ), 'permission_callback' => '__return_true' ) );
		register_rest_route( self::NAMESPACE, '/hub/jobs/(?P<job_id>[a-f0-9]{32})/approve', array( 'methods' => 'POST', 'callback' => array( __CLASS__, 'approve_job' ), 'permission_callback' => '__return_true' ) );
		register_rest_route( self::NAMESPACE, '/hub/jobs/(?P<job_id>[a-f0-9]{32})/chunk', array( 'methods' => 'POST', 'callback' => array( __CLASS__, 'receive_chunk' ), 'permission_callback' => '__return_true' ) );
		register_rest_route( self::NAMESPACE, '/hub/jobs/(?P<job_id>[a-f0-9]{32})/read', array( 'methods' => 'POST', 'callback' => array( __CLASS__, 'read_chunk' ), 'permission_callback' => '__return_true' ) );
		register_rest_route( self::NAMESPACE, '/hub/jobs/(?P<job_id>[a-f0-9]{32})/complete', array( 'methods' => 'POST', 'callback' => array( __CLASS__, 'complete_job' ), 'permission_callback' => '__return_true' ) );
		register_rest_route( self::NAMESPACE, '/hub/jobs/(?P<job_id>[a-f0-9]{32})/fail', array( 'methods' => 'POST', 'callback' => array( __CLASS__, 'fail_job' ), 'permission_callback' => '__return_true' ) );
	}

	/** First/clone registration. The family secret travels only over HTTPS. */
	public static function register_environment( $request ) {
		$ready = self::hub_ready();
		if ( is_wp_error( $ready ) ) {
			return $ready;
		}
		if ( ! is_ssl() && wp_get_environment_type() === 'production' ) {
			return new WP_Error( 'leadwerk_hub_https_required', __( 'Hub registration requires HTTPS.', 'leadwerk-migration' ), array( 'status' => 403 ) );
		}

		$data = $request->get_json_params();
		$data = is_array( $data ) ? $data : array();
		$family_id = isset( $data['family_id'] ) ? strtolower( trim( (string) $data['family_id'] ) ) : '';
		$family_secret = isset( $data['family_secret'] ) ? trim( (string) $data['family_secret'] ) : '';
		$environment_id = isset( $data['environment_id'] ) ? strtolower( trim( (string) $data['environment_id'] ) ) : '';
		$environment_secret = isset( $data['environment_secret'] ) ? trim( (string) $data['environment_secret'] ) : '';

		if ( ! Leadwerk_Migration_Site_Identity::valid_id( $family_id ) || ! Leadwerk_Migration_Site_Identity::valid_id( $environment_id ) || ! preg_match( '/\A[a-f0-9]{64}\z/D', $family_secret ) || ! preg_match( '/\A[a-f0-9]{64}\z/D', $environment_secret ) ) {
			return new WP_Error( 'leadwerk_hub_invalid_identity', __( 'The Site Sync identity is invalid.', 'leadwerk-migration' ), array( 'status' => 400 ) );
		}

		global $wpdb;
		$tables = self::tables();
		$family = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$tables['families']} WHERE family_id = %s", $family_id ), ARRAY_A );
		$settings = Leadwerk_Migration_Site_Identity::settings();
		$now = gmdate( 'Y-m-d H:i:s' );
		$auto = ! empty( $settings['hub_auto_approve'] );

		if ( ! is_array( $family ) ) {
			$wpdb->insert(
				$tables['families'],
				array(
					'family_id' => $family_id,
					'secret_hash' => password_hash( $family_secret, PASSWORD_DEFAULT ),
					'project_name' => self::clean_project_name( isset( $data['project_name'] ) ? $data['project_name'] : '' ),
					'status' => $auto ? 'approved' : 'pending',
					'created_at' => $now,
					'updated_at' => $now,
				),
				array( '%s', '%s', '%s', '%s', '%s', '%s' )
			);
			$family = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$tables['families']} WHERE family_id = %s", $family_id ), ARRAY_A );
		} elseif ( ! password_verify( $family_secret, $family['secret_hash'] ) ) {
			return new WP_Error( 'leadwerk_hub_family_proof_failed', __( 'The Zone Zero family proof is invalid.', 'leadwerk-migration' ), array( 'status' => 403 ) );
		}

		$existing = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$tables['environments']} WHERE environment_id = %s", $environment_id ), ARRAY_A );
		$record = array(
			'family_id'          => $family_id,
			'site_url'           => Leadwerk_Migration_Site_Identity::normalize_url( isset( $data['site_url'] ) ? $data['site_url'] : '' ),
			'environment_type'   => self::clean_environment_type( isset( $data['environment_type'] ) ? $data['environment_type'] : '' ),
			'wordpress_version'  => substr( sanitize_text_field( isset( $data['wordpress_version'] ) ? $data['wordpress_version'] : '' ), 0, 32 ),
			'php_version'        => substr( sanitize_text_field( isset( $data['php_version'] ) ? $data['php_version'] : '' ), 0, 32 ),
			'plugin_version'     => substr( sanitize_text_field( isset( $data['plugin_version'] ) ? $data['plugin_version'] : '' ), 0, 32 ),
			'fingerprint'        => preg_match( '/\A[a-f0-9]{64}\z/D', isset( $data['fingerprint'] ) ? $data['fingerprint'] : '' ) ? $data['fingerprint'] : hash( 'sha256', $environment_id ),
			'updated_at'         => $now,
			'last_seen_at'       => $now,
		);

		if ( is_array( $existing ) ) {
			if ( ! hash_equals( $existing['family_id'], $family_id ) ) {
				return new WP_Error( 'leadwerk_hub_environment_conflict', __( 'This environment identity already belongs to another Site Family.', 'leadwerk-migration' ), array( 'status' => 409 ) );
			}
			$stored_secret = self::open_secret( $existing['secret_encrypted'] );
			if ( ! is_string( $stored_secret ) || ! hash_equals( $stored_secret, $environment_secret ) ) {
				return new WP_Error( 'leadwerk_hub_environment_proof_failed', __( 'The environment credential is invalid.', 'leadwerk-migration' ), array( 'status' => 403 ) );
			}
			$wpdb->update( $tables['environments'], $record, array( 'environment_id' => $environment_id ) );
		} else {
			$record['environment_id']   = $environment_id;
			$record['secret_encrypted'] = self::seal_secret( $environment_secret );
			$record['status']           = $auto && isset( $family['status'] ) && $family['status'] === 'approved' ? 'approved' : 'pending';
			$record['created_at']       = $now;
			$wpdb->insert( $tables['environments'], $record );
		}

		$environment = $wpdb->get_row( $wpdb->prepare( "SELECT status FROM {$tables['environments']} WHERE environment_id = %s", $environment_id ), ARRAY_A );
		return new WP_REST_Response(
			array(
				'family_status'      => isset( $family['status'] ) ? $family['status'] : 'pending',
				'environment_status' => isset( $environment['status'] ) ? $environment['status'] : 'pending',
				'environment_id'     => $environment_id,
				'hub_time'           => gmdate( 'c' ),
			),
			200
		);
	}

	public static function heartbeat( $request ) {
		$auth = self::authenticate( $request );
		if ( is_wp_error( $auth ) ) {
			return $auth;
		}
		$data = $request->get_json_params();
		$data = is_array( $data ) ? $data : array();
		global $wpdb;
		$tables = self::tables();
		$wpdb->update(
			$tables['environments'],
			array(
				'site_url'          => Leadwerk_Migration_Site_Identity::normalize_url( isset( $data['site_url'] ) ? $data['site_url'] : $auth['site_url'] ),
				'environment_type'  => self::clean_environment_type( isset( $data['environment_type'] ) ? $data['environment_type'] : $auth['environment_type'] ),
				'wordpress_version' => substr( sanitize_text_field( isset( $data['wordpress_version'] ) ? $data['wordpress_version'] : $auth['wordpress_version'] ), 0, 32 ),
				'php_version'       => substr( sanitize_text_field( isset( $data['php_version'] ) ? $data['php_version'] : $auth['php_version'] ), 0, 32 ),
				'plugin_version'    => substr( sanitize_text_field( isset( $data['plugin_version'] ) ? $data['plugin_version'] : $auth['plugin_version'] ), 0, 32 ),
				'last_seen_at'      => gmdate( 'Y-m-d H:i:s' ),
				'updated_at'        => gmdate( 'Y-m-d H:i:s' ),
			),
			array( 'environment_id' => $auth['environment_id'] )
		);
		return new WP_REST_Response( array( 'status' => $auth['status'], 'hub_time' => gmdate( 'c' ) ), 200 );
	}

	public static function directory( $request ) {
		$auth = self::authenticate_approved( $request );
		if ( is_wp_error( $auth ) ) {
			return $auth;
		}
		global $wpdb;
		$tables = self::tables();
		$rows = $wpdb->get_results(
			$wpdb->prepare( "SELECT environment_id, site_url, environment_type, wordpress_version, php_version, plugin_version, status, last_seen_at FROM {$tables['environments']} WHERE family_id = %s AND status IN ('approved','pending') ORDER BY environment_type, site_url", $auth['family_id'] ),
			ARRAY_A
		);
		foreach ( is_array( $rows ) ? $rows : array() as $index => $row ) {
			$rows[ $index ] = self::decorate_environment_status( $row );
		}
		return new WP_REST_Response( array( 'environments' => is_array( $rows ) ? $rows : array() ), 200 );
	}

	public static function create_job( $request ) {
		$auth = self::authenticate_approved( $request );
		if ( is_wp_error( $auth ) ) {
			return $auth;
		}
		$data = $request->get_json_params();
		$data = is_array( $data ) ? $data : array();
		$source_id = isset( $data['source_environment_id'] ) ? strtolower( trim( (string) $data['source_environment_id'] ) ) : '';
		$target_id = isset( $data['target_environment_id'] ) ? strtolower( trim( (string) $data['target_environment_id'] ) ) : '';
		if ( $source_id === $target_id || ! in_array( $auth['environment_id'], array( $source_id, $target_id ), true ) ) {
			return new WP_Error( 'leadwerk_sync_invalid_direction', __( 'A sync request must involve the current environment and two different endpoints.', 'leadwerk-migration' ), array( 'status' => 400 ) );
		}

		global $wpdb;
		$tables = self::tables();
		$source = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$tables['environments']} WHERE environment_id = %s AND family_id = %s AND status = 'approved'", $source_id, $auth['family_id'] ), ARRAY_A );
		$target = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$tables['environments']} WHERE environment_id = %s AND family_id = %s AND status = 'approved'", $target_id, $auth['family_id'] ), ARRAY_A );
		if ( ! is_array( $source ) || ! is_array( $target ) ) {
			return new WP_Error( 'leadwerk_sync_environment_not_approved', __( 'Both environments must be approved in the Leadwerk Hub.', 'leadwerk-migration' ), array( 'status' => 409 ) );
		}
		if ( $source['wordpress_version'] === '' || ! hash_equals( $source['wordpress_version'], $target['wordpress_version'] ) ) {
			return new WP_Error( 'leadwerk_sync_wordpress_mismatch', sprintf( __( 'Sync blocked: WordPress versions differ (%1$s → %2$s). Make the versions identical and try again.', 'leadwerk-migration' ), $source['wordpress_version'], $target['wordpress_version'] ), array( 'status' => 409 ) );
		}
		if ( $source['php_version'] === '' || ! hash_equals( $source['php_version'], $target['php_version'] ) ) {
			return new WP_Error( 'leadwerk_sync_php_mismatch', sprintf( __( 'Sync blocked: PHP versions differ (%1$s → %2$s). Make the versions identical and try again.', 'leadwerk-migration' ), $source['php_version'], $target['php_version'] ), array( 'status' => 409 ) );
		}
		if ( $source['plugin_version'] === '' || ! hash_equals( $source['plugin_version'], $target['plugin_version'] ) ) {
			return new WP_Error( 'leadwerk_sync_plugin_mismatch', sprintf( __( 'Sync blocked: Leadwerk Migration versions differ (%1$s → %2$s).', 'leadwerk-migration' ), $source['plugin_version'], $target['plugin_version'] ), array( 'status' => 409 ) );
		}
		if ( ! self::environment_is_online( $source ) || ! self::environment_is_online( $target ) ) {
			return new WP_Error( 'leadwerk_sync_environment_offline', __( 'Sync blocked: source and target must both have contacted Leadwerk Hub within the last 15 minutes. Bring both environments online and try again.', 'leadwerk-migration' ), array( 'status' => 409 ) );
		}

		$job_id = Leadwerk_Migration_Site_Identity::random_id();
		$now = gmdate( 'Y-m-d H:i:s' );
		$expires = gmdate( 'Y-m-d H:i:s', time() + DAY_IN_SECONDS );
		$wpdb->insert(
			$tables['jobs'],
			array(
				'job_id' => $job_id,
				'family_id' => $auth['family_id'],
				'source_environment_id' => $source_id,
				'target_environment_id' => $target_id,
				'initiator_environment_id' => $auth['environment_id'],
				'status' => 'approved',
				'source_approved' => 1,
				'target_approved' => 1,
				'message' => __( 'Preflight passed. The source environment will create a verified full-site backup.', 'leadwerk-migration' ),
				'created_at' => $now,
				'updated_at' => $now,
				'expires_at' => $expires,
			)
		);
		return new WP_REST_Response( array( 'job_id' => $job_id, 'status' => 'approved' ), 201 );
	}

	public static function list_jobs( $request ) {
		$auth = self::authenticate_approved( $request );
		if ( is_wp_error( $auth ) ) {
			return $auth;
		}
		global $wpdb;
		$tables = self::tables();
		$rows = $wpdb->get_results(
			$wpdb->prepare(
				"SELECT * FROM {$tables['jobs']} WHERE family_id = %s AND (source_environment_id = %s OR target_environment_id = %s) ORDER BY created_at DESC LIMIT 50",
				$auth['family_id'],
				$auth['environment_id'],
				$auth['environment_id']
			),
			ARRAY_A
		);
		return new WP_REST_Response( array( 'jobs' => is_array( $rows ) ? $rows : array() ), 200 );
	}

	public static function approve_job( $request ) {
		$auth = self::authenticate_approved( $request );
		if ( is_wp_error( $auth ) ) {
			return $auth;
		}
		$job = self::job_for_environment( $request['job_id'], $auth );
		if ( is_wp_error( $job ) ) {
			return $job;
		}
		if ( ! in_array( $job['status'], array( 'awaiting_approval', 'approved' ), true ) ) {
			return new WP_Error( 'leadwerk_sync_job_not_approvable', __( 'This sync job can no longer be approved.', 'leadwerk-migration' ), array( 'status' => 409 ) );
		}
		global $wpdb;
		$tables = self::tables();
		$changes = array( 'updated_at' => gmdate( 'Y-m-d H:i:s' ) );
		if ( hash_equals( $job['source_environment_id'], $auth['environment_id'] ) ) {
			$changes['source_approved'] = 1;
		}
		if ( hash_equals( $job['target_environment_id'], $auth['environment_id'] ) ) {
			$changes['target_approved'] = 1;
		}
		$source_approved = ! empty( $changes['source_approved'] ) || ! empty( $job['source_approved'] );
		$target_approved = ! empty( $changes['target_approved'] ) || ! empty( $job['target_approved'] );
		if ( $source_approved && $target_approved ) {
			$changes['status']  = 'approved';
			$changes['message'] = __( 'Approved. The source environment will create a verified backup.', 'leadwerk-migration' );
		}
		$wpdb->update( $tables['jobs'], $changes, array( 'job_id' => $job['job_id'] ) );
		return new WP_REST_Response( array( 'job_id' => $job['job_id'], 'status' => isset( $changes['status'] ) ? $changes['status'] : 'awaiting_approval' ), 200 );
	}

	public static function receive_chunk( $request ) {
		$auth = self::authenticate_approved( $request );
		if ( is_wp_error( $auth ) ) {
			return $auth;
		}
		$job = self::job_for_environment( $request['job_id'], $auth );
		if ( is_wp_error( $job ) || ! hash_equals( $job['source_environment_id'], $auth['environment_id'] ) ) {
			return is_wp_error( $job ) ? $job : new WP_Error( 'leadwerk_sync_not_source', __( 'Only the approved source can upload archive chunks.', 'leadwerk-migration' ), array( 'status' => 403 ) );
		}
		if ( ! in_array( $job['status'], array( 'approved', 'transferring' ), true ) ) {
			return new WP_Error( 'leadwerk_sync_upload_not_ready', __( 'This job is not accepting archive data.', 'leadwerk-migration' ), array( 'status' => 409 ) );
		}

		$data = $request->get_json_params();
		$data = is_array( $data ) ? $data : array();
		$offset = isset( $data['offset'] ) ? (int) $data['offset'] : -1;
		$total  = isset( $data['total'] ) ? (int) $data['total'] : 0;
		$sha256 = isset( $data['sha256'] ) ? strtolower( trim( (string) $data['sha256'] ) ) : '';
		$name   = isset( $data['archive_name'] ) ? sanitize_file_name( $data['archive_name'] ) : '';
		$chunk  = isset( $data['data'] ) && is_string( $data['data'] ) ? base64_decode( $data['data'], true ) : false;
		if ( $offset < 0 || $total <= 0 || ! preg_match( '/\A[a-f0-9]{64}\z/D', $sha256 ) || ! leadwerk_migration_is_filename_supported( $name ) || ! is_string( $chunk ) || $chunk === '' || strlen( $chunk ) > LEADWERK_MIGRATION_SYNC_CHUNK_SIZE ) {
			return new WP_Error( 'leadwerk_sync_invalid_chunk', __( 'The archive chunk metadata is invalid.', 'leadwerk-migration' ), array( 'status' => 400 ) );
		}

		$path = self::relay_path( $job['job_id'] );
		$current_size = is_file( $path ) ? (int) filesize( $path ) : 0;
		if ( $current_size !== $offset || (int) $job['bytes_received'] !== $offset ) {
			return new WP_Error( 'leadwerk_sync_chunk_offset', sprintf( __( 'Chunk offset mismatch. Expected %d bytes.', 'leadwerk-migration' ), $current_size ), array( 'status' => 409, 'expected_offset' => $current_size ) );
		}
		$handle = @fopen( $path, $offset === 0 ? 'wb' : 'ab' );
		if ( $handle === false || ! flock( $handle, LOCK_EX ) ) {
			return new WP_Error( 'leadwerk_sync_relay_write_failed', __( 'The Hub relay file could not be locked for writing.', 'leadwerk-migration' ), array( 'status' => 500 ) );
		}
		$written = fwrite( $handle, $chunk );
		fflush( $handle );
		flock( $handle, LOCK_UN );
		fclose( $handle );
		if ( $written !== strlen( $chunk ) ) {
			return new WP_Error( 'leadwerk_sync_relay_write_failed', __( 'The Hub could not write the complete archive chunk.', 'leadwerk-migration' ), array( 'status' => 500 ) );
		}
		@chmod( $path, 0600 );

		$received = $offset + $written;
		$changes = array(
			'status' => 'transferring',
			'archive_name' => $name,
			'archive_size' => $total,
			'archive_sha256' => $sha256,
			'bytes_received' => $received,
			'message' => __( 'Archive is being transferred through the private Hub relay.', 'leadwerk-migration' ),
			'updated_at' => gmdate( 'Y-m-d H:i:s' ),
		);
		if ( $received === $total ) {
			$actual = hash_file( 'sha256', $path );
			if ( ! is_string( $actual ) || ! hash_equals( $sha256, strtolower( $actual ) ) ) {
				self::safe_unlink_relay( $job['job_id'] );
				self::mark_job_failed( $job['job_id'], __( 'Hub relay SHA-256 verification failed.', 'leadwerk-migration' ) );
				return new WP_Error( 'leadwerk_sync_relay_integrity_failed', __( 'The transferred archive failed SHA-256 verification.', 'leadwerk-migration' ), array( 'status' => 409 ) );
			}
			$changes['status']  = 'ready';
			$changes['message'] = __( 'Verified archive is ready for the target environment.', 'leadwerk-migration' );
		} elseif ( $received > $total ) {
			self::safe_unlink_relay( $job['job_id'] );
			return new WP_Error( 'leadwerk_sync_relay_overflow', __( 'The received archive is larger than declared.', 'leadwerk-migration' ), array( 'status' => 409 ) );
		}

		global $wpdb;
		$tables = self::tables();
		$wpdb->update( $tables['jobs'], $changes, array( 'job_id' => $job['job_id'] ) );
		return new WP_REST_Response( array( 'job_id' => $job['job_id'], 'status' => $changes['status'], 'bytes_received' => $received ), 200 );
	}

	public static function read_chunk( $request ) {
		$auth = self::authenticate_approved( $request );
		if ( is_wp_error( $auth ) ) {
			return $auth;
		}
		$job = self::job_for_environment( $request['job_id'], $auth );
		if ( is_wp_error( $job ) || ! hash_equals( $job['target_environment_id'], $auth['environment_id'] ) ) {
			return is_wp_error( $job ) ? $job : new WP_Error( 'leadwerk_sync_not_target', __( 'Only the approved target can read archive chunks.', 'leadwerk-migration' ), array( 'status' => 403 ) );
		}
		if ( ! in_array( $job['status'], array( 'ready', 'receiving' ), true ) ) {
			return new WP_Error( 'leadwerk_sync_archive_not_ready', __( 'The verified archive is not ready yet.', 'leadwerk-migration' ), array( 'status' => 409 ) );
		}
		$data = $request->get_json_params();
		$offset = is_array( $data ) && isset( $data['offset'] ) ? max( 0, (int) $data['offset'] ) : 0;
		$length = is_array( $data ) && isset( $data['length'] ) ? max( 1, min( LEADWERK_MIGRATION_SYNC_CHUNK_SIZE, (int) $data['length'] ) ) : LEADWERK_MIGRATION_SYNC_CHUNK_SIZE;
		$path = self::relay_path( $job['job_id'] );
		if ( ! is_file( $path ) || $offset >= (int) $job['archive_size'] ) {
			return new WP_Error( 'leadwerk_sync_relay_missing', __( 'The Hub relay archive is unavailable.', 'leadwerk-migration' ), array( 'status' => 404 ) );
		}
		$handle = @fopen( $path, 'rb' );
		if ( $handle === false || fseek( $handle, $offset ) !== 0 ) {
			return new WP_Error( 'leadwerk_sync_relay_read_failed', __( 'The Hub relay archive could not be read.', 'leadwerk-migration' ), array( 'status' => 500 ) );
		}
		$chunk = fread( $handle, $length );
		fclose( $handle );
		if ( ! is_string( $chunk ) || $chunk === '' ) {
			return new WP_Error( 'leadwerk_sync_relay_read_failed', __( 'The Hub returned an empty archive chunk.', 'leadwerk-migration' ), array( 'status' => 500 ) );
		}
		global $wpdb;
		$tables = self::tables();
		$wpdb->update( $tables['jobs'], array( 'status' => 'receiving', 'updated_at' => gmdate( 'Y-m-d H:i:s' ) ), array( 'job_id' => $job['job_id'] ) );
		return new WP_REST_Response(
			array(
				'job_id' => $job['job_id'],
				'offset' => $offset,
				'length' => strlen( $chunk ),
				'total'  => (int) $job['archive_size'],
				'sha256' => $job['archive_sha256'],
				'archive_name' => $job['archive_name'],
				'data'   => base64_encode( $chunk ),
			),
			200
		);
	}

	public static function complete_job( $request ) {
		$auth = self::authenticate_approved( $request );
		if ( is_wp_error( $auth ) ) {
			return $auth;
		}
		$job = self::job_for_environment( $request['job_id'], $auth );
		if ( is_wp_error( $job ) || ! hash_equals( $job['target_environment_id'], $auth['environment_id'] ) ) {
			return is_wp_error( $job ) ? $job : new WP_Error( 'leadwerk_sync_not_target', __( 'Only the target can complete this sync.', 'leadwerk-migration' ), array( 'status' => 403 ) );
		}
		global $wpdb;
		$tables = self::tables();
		$wpdb->update( $tables['jobs'], array( 'status' => 'complete', 'message' => __( 'Full-site sync completed successfully.', 'leadwerk-migration' ), 'updated_at' => gmdate( 'Y-m-d H:i:s' ) ), array( 'job_id' => $job['job_id'] ) );
		self::safe_unlink_relay( $job['job_id'] );
		return new WP_REST_Response( array( 'job_id' => $job['job_id'], 'status' => 'complete' ), 200 );
	}

	public static function fail_job( $request ) {
		$auth = self::authenticate_approved( $request );
		if ( is_wp_error( $auth ) ) {
			return $auth;
		}
		$job = self::job_for_environment( $request['job_id'], $auth );
		if ( is_wp_error( $job ) ) {
			return $job;
		}
		$data = $request->get_json_params();
		$message = is_array( $data ) && isset( $data['message'] ) ? sanitize_text_field( $data['message'] ) : __( 'Environment reported a sync failure.', 'leadwerk-migration' );
		self::mark_job_failed( $job['job_id'], $message );
		self::safe_unlink_relay( $job['job_id'] );
		return new WP_REST_Response( array( 'job_id' => $job['job_id'], 'status' => 'failed' ), 200 );
	}

	/** Verify a replay-resistant HMAC request and return the environment row. */
	private static function authenticate( $request ) {
		$ready = self::hub_ready();
		if ( is_wp_error( $ready ) ) {
			return $ready;
		}
		$environment_id = strtolower( trim( (string) $request->get_header( 'X-Leadwerk-Environment' ) ) );
		$timestamp      = (int) $request->get_header( 'X-Leadwerk-Timestamp' );
		$nonce          = strtolower( trim( (string) $request->get_header( 'X-Leadwerk-Nonce' ) ) );
		$signature      = strtolower( trim( (string) $request->get_header( 'X-Leadwerk-Signature' ) ) );
		if ( ! Leadwerk_Migration_Site_Identity::valid_id( $environment_id ) || abs( time() - $timestamp ) > self::MAX_CLOCK_SKEW || ! preg_match( '/\A[a-f0-9]{32}\z/D', $nonce ) || ! preg_match( '/\A[a-f0-9]{64}\z/D', $signature ) ) {
			return new WP_Error( 'leadwerk_hub_auth_invalid', __( 'The signed Hub request is invalid or expired.', 'leadwerk-migration' ), array( 'status' => 401 ) );
		}
		$nonce_key = 'leadwerk_sync_nonce_' . hash( 'sha256', $environment_id . '|' . $nonce );
		if ( get_transient( $nonce_key ) ) {
			return new WP_Error( 'leadwerk_hub_replay', __( 'This signed Hub request has already been used.', 'leadwerk-migration' ), array( 'status' => 409 ) );
		}

		global $wpdb;
		$tables = self::tables();
		$environment = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$tables['environments']} WHERE environment_id = %s", $environment_id ), ARRAY_A );
		if ( ! is_array( $environment ) || $environment['status'] === 'revoked' ) {
			return new WP_Error( 'leadwerk_hub_environment_unknown', __( 'The environment is not registered or has been revoked.', 'leadwerk-migration' ), array( 'status' => 403 ) );
		}
		$secret = self::open_secret( $environment['secret_encrypted'] );
		$body   = (string) $request->get_body();
		$route  = (string) $request->get_route();
		$canonical = self::canonical_request( $request->get_method(), $route, $timestamp, $nonce, $body );
		$expected = is_string( $secret ) ? hash_hmac( 'sha256', $canonical, $secret ) : '';
		if ( $expected === '' || ! hash_equals( $expected, $signature ) ) {
			return new WP_Error( 'leadwerk_hub_signature_failed', __( 'The Hub request signature is invalid.', 'leadwerk-migration' ), array( 'status' => 401 ) );
		}
		set_transient( $nonce_key, 1, self::MAX_CLOCK_SKEW * 2 );
		return $environment;
	}

	private static function authenticate_approved( $request ) {
		$environment = self::authenticate( $request );
		if ( is_wp_error( $environment ) ) {
			return $environment;
		}
		if ( $environment['status'] !== 'approved' ) {
			return new WP_Error( 'leadwerk_hub_environment_pending', __( 'The environment is waiting for Hub administrator approval.', 'leadwerk-migration' ), array( 'status' => 403 ) );
		}
		global $wpdb;
		$tables = self::tables();
		$family_status = $wpdb->get_var( $wpdb->prepare( "SELECT status FROM {$tables['families']} WHERE family_id = %s", $environment['family_id'] ) );
		if ( $family_status !== 'approved' ) {
			return new WP_Error( 'leadwerk_hub_family_pending', __( 'The Site Family is waiting for Hub administrator approval.', 'leadwerk-migration' ), array( 'status' => 403 ) );
		}
		return $environment;
	}

	/** @return string */
	public static function canonical_request( $method, $route, $timestamp, $nonce, $body ) {
		return strtoupper( (string) $method ) . "\n" . (string) $route . "\n" . (int) $timestamp . "\n" . strtolower( (string) $nonce ) . "\n" . hash( 'sha256', (string) $body );
	}

	/** @return array<string, string> */
	public static function tables() {
		global $wpdb;
		return array(
			'families'     => $wpdb->prefix . 'leadwerk_sync_families',
			'environments' => $wpdb->prefix . 'leadwerk_sync_environments',
			'jobs'         => $wpdb->prefix . 'leadwerk_sync_jobs',
		);
	}

	/** Admin-facing registry data. */
	public static function admin_data() {
		if ( ! self::enabled() ) {
			return array( 'families' => array(), 'environments' => array(), 'jobs' => array() );
		}
		self::maybe_install();
		global $wpdb;
		$tables = self::tables();
		$environments = $wpdb->get_results( "SELECT environment_id, family_id, site_url, environment_type, wordpress_version, php_version, plugin_version, status, last_seen_at FROM {$tables['environments']} ORDER BY last_seen_at DESC LIMIT 200", ARRAY_A );
		return array(
			'families' => $wpdb->get_results( "SELECT family_id, project_name, status, created_at, updated_at FROM {$tables['families']} ORDER BY created_at DESC LIMIT 100", ARRAY_A ),
			'environments' => array_map( array( __CLASS__, 'decorate_environment_status' ), is_array( $environments ) ? $environments : array() ),
			'jobs' => $wpdb->get_results( "SELECT * FROM {$tables['jobs']} ORDER BY created_at DESC LIMIT 100", ARRAY_A ),
		);
	}

	/** A heartbeat is fresh for three worker intervals. */
	public static function environment_is_online( $environment ) {
		if ( ! is_array( $environment ) || empty( $environment['last_seen_at'] ) ) {
			return false;
		}
		$last_seen = strtotime( $environment['last_seen_at'] . ' UTC' );
		return false !== $last_seen && $last_seen >= time() - self::ONLINE_TTL;
	}

	/** Add display-safe liveness data without exposing credentials. */
	public static function decorate_environment_status( $environment ) {
		$environment = is_array( $environment ) ? $environment : array();
		$last_seen = ! empty( $environment['last_seen_at'] ) ? strtotime( $environment['last_seen_at'] . ' UTC' ) : false;
		$environment['is_online'] = self::environment_is_online( $environment );
		$environment['last_seen_seconds_ago'] = false !== $last_seen ? max( 0, time() - $last_seen ) : null;
		return $environment;
	}

	public static function set_registry_status( $kind, $id, $status ) {
		if ( ! self::enabled() || ! in_array( $status, array( 'approved', 'revoked' ), true ) ) {
			return false;
		}
		global $wpdb;
		$tables = self::tables();
		if ( $kind === 'family' && Leadwerk_Migration_Site_Identity::valid_id( $id ) ) {
			$result = $wpdb->update( $tables['families'], array( 'status' => $status, 'updated_at' => gmdate( 'Y-m-d H:i:s' ) ), array( 'family_id' => $id ) );
			if ( $status === 'revoked' ) {
				$wpdb->update( $tables['environments'], array( 'status' => 'revoked', 'updated_at' => gmdate( 'Y-m-d H:i:s' ) ), array( 'family_id' => $id ) );
			}
			return false !== $result;
		}
		if ( $kind === 'environment' && Leadwerk_Migration_Site_Identity::valid_id( $id ) ) {
			return false !== $wpdb->update( $tables['environments'], array( 'status' => $status, 'updated_at' => gmdate( 'Y-m-d H:i:s' ) ), array( 'environment_id' => $id ) );
		}
		return false;
	}

	public static function cleanup() {
		if ( ! self::enabled() ) {
			return;
		}
		global $wpdb;
		$tables = self::tables();
		$expired = $wpdb->get_col( $wpdb->prepare( "SELECT job_id FROM {$tables['jobs']} WHERE expires_at < %s OR status IN ('complete','failed','canceled')", gmdate( 'Y-m-d H:i:s' ) ) );
		foreach ( is_array( $expired ) ? $expired : array() as $job_id ) {
			self::safe_unlink_relay( $job_id );
		}
	}

	private static function hub_ready() {
		if ( ! self::enabled() ) {
			return new WP_Error( 'leadwerk_hub_disabled', __( 'Leadwerk Hub mode is disabled on this server.', 'leadwerk-migration' ), array( 'status' => 404 ) );
		}
		if ( ! function_exists( 'openssl_encrypt' ) || ! function_exists( 'openssl_decrypt' ) ) {
			return new WP_Error( 'leadwerk_hub_openssl_missing', __( 'Leadwerk Hub requires the PHP OpenSSL extension to protect environment credentials at rest.', 'leadwerk-migration' ), array( 'status' => 503 ) );
		}
		self::maybe_install();
		$relay = self::ensure_relay_directory();
		if ( is_wp_error( $relay ) ) {
			return $relay;
		}
		return true;
	}

	private static function job_for_environment( $job_id, $environment ) {
		if ( ! Leadwerk_Migration_Site_Identity::valid_id( $job_id ) ) {
			return new WP_Error( 'leadwerk_sync_job_invalid', __( 'The sync job identifier is invalid.', 'leadwerk-migration' ), array( 'status' => 400 ) );
		}
		global $wpdb;
		$tables = self::tables();
		$job = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$tables['jobs']} WHERE job_id = %s AND family_id = %s", $job_id, $environment['family_id'] ), ARRAY_A );
		if ( ! is_array( $job ) || ! in_array( $environment['environment_id'], array( $job['source_environment_id'], $job['target_environment_id'] ), true ) ) {
			return new WP_Error( 'leadwerk_sync_job_not_found', __( 'The sync job was not found.', 'leadwerk-migration' ), array( 'status' => 404 ) );
		}
		return $job;
	}

	private static function relay_directory() {
		return LEADWERK_MIGRATION_PRIVATE_ROOT . DIRECTORY_SEPARATOR . 'leadwerk-sync-relay-' . substr( hash( 'sha256', ABSPATH . wp_salt( 'auth' ) ), 0, 12 );
	}

	private static function ensure_relay_directory() {
		$directory = self::relay_directory();
		if ( ! Leadwerk_Migration_Security::path_is_private( $directory ) ) {
			return new WP_Error( 'leadwerk_sync_relay_not_private', __( 'Hub relay storage is not outside the web root.', 'leadwerk-migration' ) );
		}
		if ( ! is_dir( $directory ) && ! wp_mkdir_p( $directory ) ) {
			return new WP_Error( 'leadwerk_sync_relay_unavailable', __( 'Hub relay storage could not be created.', 'leadwerk-migration' ) );
		}
		@chmod( $directory, 0700 );
		return $directory;
	}

	private static function relay_path( $job_id ) {
		$directory = self::ensure_relay_directory();
		return is_wp_error( $directory ) ? '' : $directory . DIRECTORY_SEPARATOR . $job_id . '.wpress';
	}

	private static function safe_unlink_relay( $job_id ) {
		if ( ! Leadwerk_Migration_Site_Identity::valid_id( $job_id ) ) {
			return false;
		}
		$path = self::relay_path( $job_id );
		return $path !== '' && is_file( $path ) ? @unlink( $path ) : true;
	}

	private static function mark_job_failed( $job_id, $message ) {
		global $wpdb;
		$tables = self::tables();
		$wpdb->update( $tables['jobs'], array( 'status' => 'failed', 'message' => substr( sanitize_text_field( $message ), 0, 1000 ), 'updated_at' => gmdate( 'Y-m-d H:i:s' ) ), array( 'job_id' => $job_id ) );
	}

	private static function seal_secret( $secret ) {
		if ( ! function_exists( 'openssl_encrypt' ) ) {
			return '';
		}
		$key = hash( 'sha256', wp_salt( 'auth' ), true );
		$iv  = random_bytes( 12 );
		$tag = '';
		$ciphertext = openssl_encrypt( $secret, 'aes-256-gcm', $key, OPENSSL_RAW_DATA, $iv, $tag, 'leadwerk-sync-hub-v1' );
		return is_string( $ciphertext ) ? base64_encode( $iv . $tag . $ciphertext ) : '';
	}

	private static function open_secret( $sealed ) {
		$raw = is_string( $sealed ) ? base64_decode( $sealed, true ) : false;
		if ( ! is_string( $raw ) || strlen( $raw ) < 29 || ! function_exists( 'openssl_decrypt' ) ) {
			return false;
		}
		$key = hash( 'sha256', wp_salt( 'auth' ), true );
		return openssl_decrypt( substr( $raw, 28 ), 'aes-256-gcm', $key, OPENSSL_RAW_DATA, substr( $raw, 0, 12 ), substr( $raw, 12, 16 ), 'leadwerk-sync-hub-v1' );
	}

	private static function clean_project_name( $name ) {
		$name = trim( sanitize_text_field( (string) $name ) );
		return substr( $name !== '' ? $name : 'Leadwerk Project', 0, 190 );
	}

	private static function clean_environment_type( $type ) {
		$type = sanitize_key( (string) $type );
		return in_array( $type, array( 'local', 'staging', 'live' ), true ) ? $type : 'live';
	}
}
